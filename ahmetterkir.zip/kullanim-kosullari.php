<?php require_once "header.php" ?>
	<div id="page-head" class="container-fluid inner-page">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<div class="page-title">Kullanım Koşulları</div>
				</div>
			</div>
		</div>
	</div>
	<div id="page-content" class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="content-holder" >
                        <p>
                            <?php echo $query[0]['Sozlesme']; ?>
                        </p>
					</div>
				</div>
			</div>
		</div>
	</div>
    <?php require_once "footer.php"; ?>