<?php
session_start();
session_destroy();
session_unset();
unset($_SESSION['oturum']);
unset($_SESSION['Kullanici']);
unset($_SESSION['Sifre']);
unset($_SESSION['Id']);
header('Location: ../index.php');
?>