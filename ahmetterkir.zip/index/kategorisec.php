<?php

$kategoriSec=$_GET["kategori"];

if (strlen($kategoriSec) > 0 && isset($kategoriSec)) {
    getCategories($kategoriSec);
}
                                    
function getCategories($cat){
    try{
        require_once '../sys/BasicDB.php';
        require_once '../sys/function.php';
    }catch (PDOException $h) {

        $hata=$h->getMessage();

        echo "<b>HATA VAR :</b> ".$hata;

    }
        $query = $db->from('servisler')
            ->where('KategoriAdi', $cat)
            ->where('Durum', 'Aktif')
            ->orderby('Fiyat', 'ASC')
            ->all();
        echo json_encode($query);
}

function getCategoriesDetails($id){
    try{
        require_once '../sys/BasicDB.php';
    }catch (PDOException $h) {

        $hata=$h->getMessage();

        echo "<b>HATA VAR :</b> ".$hata;

    }
    $sth = $baglanti->prepare("SELECT Aciklama FROM servisler where Id='".$id."' ORDER BY Fiyat ASC" );
    $sth->execute();
    $result = $sth->fetchAll(\PDO::FETCH_ASSOC);
    echo json_encode($result);
                                    
}

?>

