<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];
?>
<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php 
			include "header.php";
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="destek.php">Destek Sistemi</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                    	<li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <?php
                $duyuru = $db->from('duyuru')
                    ->where('DuyuruBolumu', 'destek')
                    ->all();
                for ($i=0; $i <count($duyuru) ; $i++) {
                    echo ' 
                            <div class="well"  style="background-color: fff">
                                <p style="text-align: center;">
                                    '.$duyuru[$i]["DuyuruAciklama"].'
                                </p>
                            </div>
                        ';
                }
                ?>
                <div class="row col-lg-10 col-md-10 col-xs-12 col-md-offset-1 col-xs-offset-0" >
            <div class="row">
                <div class="content-wrapper">
                    <div class="col-lg-10 col-md-10  col-xs-12 col-md-offset-1 col-xs-offset-0 ">

                        <div class=="button_css2" > 
                            <a href="destek-talepleri.php"><button type="submit" class="btn btn-info btn-fill btn-wd">Destek Taleplerim</button></a> 
                        </div>
                        <div class="panel panel-info">
                            <div class="panel-heading" >
                                DESTEK TALEBİ
                            </div>
                            <div class="panel-body">
                                    <form role="form"  action="main.php?id=<?php echo $KullaniciId; ?>" method="post">
                                            <div class="form-group">
                                                <label>Konu</label>
                                                <select class="form-control border-input" name="baslik" >
                                                    <option value="Siparişler">Siparişler</option>
                                                    <option value="Üyelik">Üyelik</option>
                                                    <option value="Teknik">Teknik</option>
                                                    <option value="Diğer">Diğer</option>
                                                </select>
                                                </div>
                                            <div class="form-group " >
                                            <label>Mesajınız</label>
                                            <textarea class="form-control border-input" rows="7" name="mesaj"></textarea>
                                        </div>
                                        <div class="text-left">
                                            <button style="margin-bottom: -2px" type="submit" class="btn btn-info btn-fill btn-wd">Mesaj Gönder</button>
                                        </div>
                                    </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                </div>
            </div>
        </div>
        <?php include "footer.php" ?>

</html>
