<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];
?>
<div class="wrapper" >
	<div class="sidebar" data-background-color="white" data-active-color="danger">
        <?php include "header.php"; ?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="">Bakiye Yükle</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                    	<li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <?php
            $date = date("Y-m-d H:i:s");
            $query = $db->from('ayarlar')
            ->all();
        $odemeYontemi = $query[0]['OdemeYontemi'];
        $apiKey = $query[0]['ApiKey'];
        $apiSecret = $query[0]['ApiSecret'];
        $mail_Id = $query[0]['mail_Id'];
        $userID = $_SESSION['Id'];
        $formGoster = true;
        if ($odemeYontemi == "paywant") {
            if($_POST){
                $tutar = strip_tags($_POST["tutar"]);
                if($tutar == "" || !is_numeric($tutar))
                {
                    echo '<script>swal("Bilgi", "Tutar Alanı Boş olamaz.", "info") </script>';
                }elseif ($tutar < 10 ) {
                    echo '<script>swal("Bilgi", "Minimum ödeme tutarı 10TL.", "info") </script>';
                }else{
                    $tutar = ceil($tutar);
                    date_default_timezone_set('Europe/Istanbul');
                    include("../paywant/paywant.lib.php"); // yardımcı fonksiyon(lar)
                    /* Malik Panel için bilgileri çekelim */

                    $query = $db->from('kullanicilar')
                        ->where('Id', $userID)
                        ->all();

                    if(count($query) > 0)
                        $getirjid = $query[0]['Email'];
                    $apiKey =$apiKey; // Paywant Mağaza Key
                    $apiSecret =$apiSecret; // Paywant Mağaza Secret
                    $userID = $userID; // Kullanıcı ID, kullanan kişinin(*)
                    $returnData = $query[0]['KullaniciAdi']; // Kullanıcı adı, kullanan kişinin(*)
                    $userEmail = $getirjid; // Kullanıcı mail, kullanan kişinin(*)
                    $userIPAddress = getIPAdresi(); // IP adresi gönderimi zorunludur. Aksi takdirde kullanıcı ödeme ekranını göremez
                    $hashYarat = base64_encode(hash_hmac('sha256',"$returnData|$userEmail|$userID".$apiKey,$apiSecret,true));
                    $productData = array(
                        "name" =>  $tutar." TL Bakiye", // Ürün adı
                        "amount" => ($tutar*100),              // Ürün fiyatı, 10 TL : 1000
                        "extraData" => $tutar,             // Notify sayfasına iletilecek ekstra veri
                        "paymentChannel" => "1,2,3",    // Bu ödeme için kullanılacak ödeme kanalları
                        "commissionType" => 2           // Komisyon tipi, 2: Yansıt, 1: Üstlen
                    );
                    $postData = array(
                        'apiKey' => $apiKey,
                        'hash' => $hashYarat,
                        'returnData'=> $returnData,
                        'userEmail' => $userEmail,
                        'userIPAddress' => $userIPAddress,
                        'userID' => $userID,
                        'proApi' => true,
                        'productData' => $productData
                    );
                    $postData = http_build_query($postData);
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => "http://api.paywant.com/gateway.php",
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $postData,
                    ));
                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    curl_close($curl);
                    if ($err) {
                        echo "cURL Error #:" . $err;
                    } else {
                        $jsonDecode = json_decode($response);
                        if($jsonDecode->Status == 100)
                        {
                            $formGoster = false;
                            // echo $jsonDecode->Message;
                            // Ortak odeme sayfasina yonlendir yada iFrame ile aç
                            // header("Location:".$jsonDecode->Message);
                            if(!strpos($jsonDecode->Message,"https"))
                                $jsonDecode->Message = str_replace("http","https",$jsonDecode->Message);
                            ?>
                            <iframe seamless="seamless" style="display:block; width:1000px; height:100vh;" frameborder="0" scrolling='yes' src="<?php echo $jsonDecode->Message?>" id='odemeFrame'></iframe>
                            <?php
                        }else{
                            echo $response;
                        }
                    }
                }
            }
        } elseif ($odemeYontemi == "buypayer") {
	                	if($_POST){
                            $tutar = strip_tags($_POST["tutar"]);
                            if($tutar == "" || !is_numeric($tutar))
                            {
                                 echo '<script>swal("Bilgi", "Tutar Alanı Boş olamaz.", "info") </script>';
                            }elseif ($tutar < 10 ) {
                                echo '<script>swal("Bilgi", "Minimum ödeme tutarı 10TL.", "info") </script>';
                            }else{
                                    $tutar = ceil($tutar);
                                     date_default_timezone_set('Europe/Istanbul');

                                    $query = $db->from('kullanicilar')
                                        ->where('Id', $userID)
                                        ->all();

                                    if(count($query) > 0)
                                        $getirjid = $query[0]['Email'];

                                    	 $userID = $userID;
                                    	 $urunadi = "Bakiye Yukleme";
										$postUrl='https://www.buypayer.com/receive2.asp';
                                        $insert = $db->insert('buypayer')
                                            ->set(array(
                                                "KullaniciId" => $userID,
                                                "KullaniciAdi" => $query[0]['KullaniciAdi'],
                                                "OdemeKanali" => 1,
                                                "OdemeTutari" => $tutar,
                                                "Durum" => 'Beklemede'
                                            ));
										$siparis_id = $db->lastId();
										$xmlString='xml=<send>
										<mgzid>'.$apiSecret.'</mgzid>
										<itt>'.$tutar.'</itt>
										<sipid>'.$siparis_id.'</sipid>
										<urunadi>'.$urunadi.'</urunadi>
										<gvk>'.$apiKey.'</gvk>
										<uyemail>'.$mail_Id.'</uyemail>
										</send>';

										$Veriler = $xmlString;
										$ch = curl_init();
										curl_setopt($ch, CURLOPT_URL, $postUrl);
										curl_setopt($ch, CURLOPT_POST, 1);
										curl_setopt($ch, CURLOPT_POSTFIELDS, $Veriler);
										curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
										curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
										curl_setopt($ch, CURLOPT_TIMEOUT, 30);
										$response = curl_exec($ch);
										curl_close($ch);
										$formGoster = false;
							?> <iframe seamless="seamless" style="display:block; width:1000px; height:100vh;" frameborder="0" scrolling='yes' src="<?php echo $response?>" id='odemeFrame'></iframe><?php
                }
            }
        }elseif ($odemeYontemi == "payamar") {

            if($_POST){
                $tutar = strip_tags($_POST["tutar"]);
                if($tutar == "" || !is_numeric($tutar))
                {
                    echo '<script>swal("Bilgi", "Tutar Alanı Boş olamaz.", "info") </script>';
                }elseif ($tutar < 10 ) {
                    echo '<script>swal("Bilgi", "Minimum ödeme tutarı 10TL.", "info") </script>';
                }else{
                    $tutar = ceil($tutar);
                    $query = $db->from('kullanicilar')
                        ->where('Id', $userID)
                        ->all();

                    $merchant_id            = $mail_Id;              //Müşteri Mağaza Kodu
                    $merchant_key           = $apiKey;       //Müşteri Mağaza Key Anahtarı
                    $merchant_salt          = $apiSecret;       //Müşteri Mağaza Gizli Anahtarı

                    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız ad ve soyad bilgisi
                    $customer_namesurname   = $query[0]["KullaniciAdi"];

                    ## Müşterinizin sitenizde kayıtlı veya form vasıtasıyla aldığınız eposta adresi
                    $customer_email         = $query[0]["Email"];

                    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız telefon bilgisi
                    $customer_number        =$query[0]["Telefon"];


                    ## Tahsil edilecek tutar.
                    $payment_amount         = intval($tutar*100);   // Ondalık para birimi için lütfen : 150.50 Yapınız

                    ## Müşterinin sepet/sipariş içeriği (Aldığı Hizmet Bilgisi ÖRN: Premium Hesap)
                    $user_basket            = $tutar." TL Bakiye Yükleme";

                    ## Ödemeyi göndermek istediğiniz para birimidir.. ÖRNEK : TL - USD - EUR
                    $payment_currency       = 'TL';
                    ## Sipariş numarası: Her işlemde benzersiz olmalıdır!! Bu bilgi bildirim sayfanıza yapılacak bildirimde geri gönderilir.

                    $insert = $db->insert('payamar')
                        ->set(array(
                            "KullaniciId" => $userID,
                            "KullaniciAdi" => $query[0]['KullaniciAdi'],
                            "OdemeKanali" => 1,
                            "OdemeTutari" => $tutar,
                            "Durum" => 'Beklemede'
                        ));
                    $siparis_id = $db->lastId();

                    ## Kullanıcının IP adresi
                    if( isset( $_SERVER["HTTP_CLIENT_IP"] ) ) {
                        $ip = $_SERVER["HTTP_CLIENT_IP"];
                    } elseif( isset( $_SERVER["HTTP_X_FORWARDED_FOR"] ) ) {
                        $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
                    } else {
                        $ip = $_SERVER["REMOTE_ADDR"];
                    }


                    $cityQuery = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
                    if($cityQuery && $cityQuery['status'] == 'success') {
                        $country = $cityQuery['country'];
                        $city = $cityQuery['city'];
                    } else {
                        $country = "Türkiye";
                        $city = "Ankara";
                    }

                    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız adres bilgisi
                    $customer_address       = $country.', '.$city;

                    ## Bu Alanı değiştirmeyin.
                    $customer_ip=$ip;

                    ####### Bu kısımda herhangi bir değişiklik yapmanıza gerek yoktur. #######
                    $secure_lane  = base64_encode(hash_hmac('sha256','PYMR'.$merchant_id.'KY'.$merchant_key.'SLT'.$merchant_salt.'C:'.date('dmydmy'),true));

                    $post_vals=array(
                        'api_merchant_id'       =>$merchant_id,             // MAĞAZA KODU
                        'api_key'               =>$merchant_key,            // MAĞAZA KEY
                        'api_secret'            =>$merchant_salt,           // MAĞAZA SECRET GİZLİ ANAHTAR
                        'customer_namesurname'  =>$customer_namesurname,    // MÜŞTERİ ADSOYAD
                        'customer_email'        =>$customer_email,          // MÜŞTERİ EPOSTA ADRESİ
                        'customer_number'       =>$customer_number,         // MÜŞTERİ GSM NUMARASI
                        'customer_address'      =>$customer_address,        // MÜŞTERİ ADRES BİLGİSİ
                        'payment_amount'        =>$payment_amount,          // MÜŞTERİ ÖDEME TUTARI
                        'merchant_oid'          =>$siparis_id,            // MÜŞTERİ SİPARİŞ NUMARASI
                        'user_basket'           =>$user_basket,             // MÜŞTERİ ÜRÜN BİLGİLERİ
                        'payment_currency'      =>$payment_currency,        // PARA BİRİMİ
                        'customer_ip'           =>$customer_ip,             // MÜŞTERİ KULLANICI IP ADRESİ
                        'secure_lane'           =>$secure_lane              // PAYAMAR GÜVENLİK BİRİM ADIMI
                    );

                    $ch=curl_init();
                    curl_setopt($ch, CURLOPT_URL, "https://api.payamar.com.tr/get-token");
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_POST, 1) ;
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_vals);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
                    $result = @curl_exec($ch);

                    $formGoster = false;
                    if(curl_errno($ch))
                        die("PAYAMAR IFRAME BAGLANTI HATASI: ".curl_error($ch));

                    curl_close($ch);

                    @@$result=json_decode($result,1);

                    if(@@$result['iframe_status']=='success'){
                        $token  =$result['payamar_vpos_token'];

                        header("Location:https://payment.payamar.com.tr/".$token.'/');
                        // https://payment.payamar.com/TOKEN/
                    }else{
                        echo '<script type = "text/javascript"> swal("Bilgi", "Payamar Ödeme Yöntemi Entegreli Değil!", "info"); </script>';
                        Yonlendir("bakiye.php", 2);
                    }
                }
            }
        }
        ?>

        <?php
            if ($odemeYontemi != "shopier") {
                if ($formGoster) {
                    ?>
                    <div class="content">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-6 col-md-12">
                                    <div class="card">
                                        <div class="content">
                                            <form method="post">
                                                <div class="row">
                                                    <div>
                                                        <div class="form-group col-lg-12 col-md-12 ">
                                                            <label>Ödeme Yöntemi</label>
                                                            <select class="form-group col-lg-12 col-md-12 ">
                                                                <?php
                                                                if ($odemeYontemi == "paywant") {
                                                                    echo "<option>Paywant</option>";
                                                                } elseif ($odemeYontemi == "buypayer") {
                                                                    echo "<option>Buypayer</option>";
                                                                } elseif ($odemeYontemi == "payamar") {
                                                                    echo "<option>Payamar</option>";
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div class="form-group col-lg-12 col-md-12 ">
                                                            <label for="exampleInputEmail1"> Miktar ( Sadece Sayı
                                                                Yazınız)</label>
                                                            <input type="text" name="tutar"
                                                                   class="form-control border-input"
                                                                   placeholder="Miktarı Giriniz">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="text-left">
                                                    <button type="submit" class="btn btn-info btn-fill btn-wd">Bakiye
                                                        Yükle
                                                    </button>
                                                </div>
                                                <div class="clearfix"></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $duyuru = $db->from('duyuru')
                                        ->where('DuyuruBolumu', 'bakiyeonline')
                                        ->all();
                                    for ($i=0; $i <count($duyuru) ; $i++) {
                                        echo ' 
                                                 <div class="row col-lg-6 col-md-12">
                                                    <div class="well" style="background-color: white; ">
                                                        <p> 
                                                         '.$duyuru[$i]["DuyuruAciklama"].'
                                                        </p>
                                                    </div>
                                                </div>
                                            ';
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
        <?php
                }
            }else{
                $duyuru = $db->from('duyuru')
                    ->where('DuyuruBolumu', 'bakiye')
                    ->all();
                for ($i=0; $i <count($duyuru) ; $i++) {
                    echo ' 
                         <div class="row col-lg-12 col-md-12" style="margin-top: 30px">
                             <div class="well" style="background-color: white; ">
                                  <p style="text-align: center"> 
                                        '.$duyuru[$i]["DuyuruAciklama"].'
                                   </p>
                              </div>
                          </div>
                         ';
                }

                $shopier = $db->from('shopier')
                  ->all();
                if (count($shopier) == 0){
                    echo ' 
                         <div class="row col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                             <div class="col-lg-7 col-md-7 col-sm-7 col-xs-7 well" style="background-color: white; margin: 120px;">
                                  <p style="text-align: center"> 
                                        Shopier Paketi Eklenmedi!
                                   </p>
                              </div>
                          </div>
                          <div class="clearfix"></div>
                         ';
                }else{
                    for ($i=0; $i <count($shopier) ; $i++) {
                        echo '
                         <div class="row col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 ">
                             <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 well " style="margin-top: 30px">
					              <h4 class="card-header" style="color:red; text-align: center;">'.$shopier[$i]['Baslik'].'<br></h4>
					               <p style="margin-left:15px;"> '.$shopier[$i]['Aciklama'].'</p>
					               <a target="_blank" class="btn btn-primary" href="https://www.shopier.com/'.$shopier[$i]["Link"].'" >Satın Al</a>
                              </div>
                          </div>
                          <div class="clearfix"></div>

                    ';
                    }

                }
            }
            include "footer.php";
        ?>



</html>
