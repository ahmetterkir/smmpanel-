<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];
?>

<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php 
			include "header.php";
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="">Servisler</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                    	<li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row col-lg-12 col-md-12">
                <?php
                    $duyuru = $db->from('duyuru')
                        ->where('DuyuruBolumu', 'servisler')
                        ->all();
                    for ($i=0; $i <count($duyuru) ; $i++) {
                        echo ' 
                            <div class="well"  style="background-color: fff">
                                <p style="text-align: center;">
                                    '.$duyuru[$i]["DuyuruAciklama"].'
                                </p>
                            </div>
                        ';
                    }
                ?>
                </div>
                <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Servisler</h4>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>
                                        <th style="text-align: center;">ID</th>
                                        <th style="text-align: center;">Servis İsmi</th>
                                        <th style="text-align: center;">Minimum</th>
                                        <th style="text-align: center;">Maximum</th>
                                        <th style="text-align: center;">Fiyat</th>
                                        <th style="text-align: center;">Açıklama</th>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $query = $db->from('servisler')
                                        ->orderby('Fiyat', 'ASC')
                                        ->where('Durum', 'Aktif')
                                        ->all();

                                    $kategori = $db->from('kategori')
                                        ->where('Durum', 'Aktif')
                                        ->orderby('KategoriNo', 'ASC')
                                        ->all();
                                 if(count($kategori) > 0 ){
                                    for ($i = 0; $i < count($kategori); $i++) {
                                        echo '
	                                        <tr>
	                                        	<td colspan="6" style="text-align: center"><strong>'.$kategori[$i]['KategoriAdi'].'</strong></td>
	                                        </tr>
	                                       ';
                                        for($j = 0; $j<count($query); $j++){
                                            $KategoriAdi = $query[$j]['KategoriAdi'];

                                            if ($kategori[$i]['KategoriAdi'] == $KategoriAdi){
                                                $ServisId = $query[$j]['Id'];
                                                $Fiyat = number_format($query[$j]['Fiyat'],2);
                                                if (isset($KullaniciId)){
                                                    $ozelFiyat = $db->from('ozelfiyat')
                                                        ->where('KullaniciId', $KullaniciId)
                                                        ->where('ServisId', $ServisId)
                                                        ->all();
                                                    if ( count($ozelFiyat) > 0){
                                                        $Fiyat = number_format($ozelFiyat[0]['Fiyat'],2);
                                                    }
                                                }

                                                echo '
                                                <tr>
                                                    <td style="text-align: center;">'.$query[$j]['Id'].'</td>
                                                    <td style="text-align: center;">'.$query[$j]['ServisAdi'].'</td>
                                                    <td style="text-align: center;">'.$query[$j]['Minimum'].'</td>
                                                    <td style="text-align: center;">'.$query[$j]['Maximum'].'</td>
                                                    <td style="text-align: center;">'.$Fiyat.'<i class="fa fa-try"></td>
                                                    <td style="text-align: center; word-wrap: break-word; width:250px; " >'.$query[$j]['Aciklama'].'</td>
                                                </tr>';
                                            }
                                    }
                                 }
                                 }else{
                                     echo '
	                                       <tr>
	                                        	<td colspan="6" style="text-align: center">Tabloda Ekli Veri Yok.</td>
	                                       </tr>
	                                       ';
                                 }

                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <?php include "footer.php" ?>
</html>
