<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];
?>
<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php 
			include "header.php";
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="">Destek Talepleri</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                       <li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Destek Talepleri</h4>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead >
                                        <th style="text-align: center;">ID</th>
                                        <th style="text-align: center;">Konu</th>
                                        <th style="text-align: center;">Tarih</th>
                                        <th style="text-align: center;">Durum</th>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $totalRecord = $db->from('destek')
                                            ->where('KullaniciId', $KullaniciId)
                                            ->select('count(Id) as total')
                                            ->total();
                                        $pageLimit = 10;
                                        $pageParam = 'sayfa';
                                        $pagination = $db->pagination($totalRecord, $pageLimit, $pageParam);
                                        $query = $db->from('destek')
                                            ->where('KullaniciId', $KullaniciId)
                                            ->orderby('Id', 'DESC')
                                            ->limit($pagination['start'], $pagination['limit'])
                                            ->all();
                                        for ($i = 0; $i < count($query); $i++) {
                                            echo '
                                                       <tr style="text-align: center;">
                                                            <td>' .$query[$i]['Id']. '</td>
                                                            <td>' .$query[$i]['Baslik'].'</td>
                                                            <td>' .$query[$i]['Tarih'].'</td>
                                                            <td><a href="destek-aktif.php?id=' .$query[$i]['Id']. '" > <button  type="submit" class="btn btn-info btn-fill" >'.$query[$i]['Durum'].'</button></td></a>
                                                            
                                                       </tr>';
                                        }
                                        echo $db->showPagination('?'.$pageParam.'=[page]');
                                    ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

            </div>
        </div>
        <?php include "footer.php"; ?>
</html>
