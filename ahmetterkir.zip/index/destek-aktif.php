<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];
$KullaniciAdi = $_SESSION['Kullanici'];
?>
<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php 
			include "header.php";
            $Id = @trim(stripslashes($_GET["id"]));
            guvenlik($Id);
            if (!is_numeric($Id)){
                Yonlendir('destek-talepleri.php');
            }
            $query = $db->from('destekcevap')
                ->where('destekId', $Id)
                ->orderby('Id', 'ASC')
                ->all();

            $destek = $db->from('destek')
            ->where('Id', $Id)
            ->where('KullaniciId', $KullaniciId)
            ->all();

            if (count($destek) < 1) {
                Yonlendir('destek-talepleri.php');
            }
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="destek.php">Destek Sistemi</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                    	<li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="content">
            <div class="container-fluid">
                <div class="row col-lg-10 col-md-10 col-xs-12 col-md-offset-1 col-xs-offset-0" >
            <div class="row">
                <div class="content-wrapper">
                    <div class="col-lg-10 col-md-10  col-xs-12 col-md-offset-1 col-xs-offset-0 ">
                        <div class="well  ">
                            <div class="titcket-title"><b>Destek Başlığı : <?php echo $destek[0]['Baslik'] ?> </b></div><br>
                            <?php
                                for ($i=0; $i <count($query) ; $i++) {
                                    $Kullanici = $query[$i]['cevaplayanId'];
                                    if($Kullanici == $KullaniciId){
                                        echo '
                                        <div class="row ticket-message-block ticket-message-right well">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-11">
                                                <div class="ticket-message">
                                                    <div class="message">'.$query[$i]['Mesaj'].'</div>
                                                </div>
                                                <div class="info text-right"><br>
                                                    <strong>Kullanıcı : '.$KullaniciAdi.' </strong><br>
                                                    <small class="text"><strong>Tarih :</strong> '.$query[$i]['Tarih'].'</small>
                                                </div>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                    ';
                                    }else{
                                        echo '
                                            <div class="row ticket-message-block ticket-message-left well" >
                                                <div class="col-md-1"></div>
                                                <div class="col-md-11">
                                                    <div class="ticket-message ">
                                                        <div class="message">'.$query[$i]['Mesaj'].'</div>
                                                    </div>
                                                    <div class="info text-left"><br>
                                                        <strong>Admin İsmi : '.$query[$i]['cevaplayanId'].'</strong><br>
                                                        <small class="text"><strong>Tarih :</strong> '.$query[$i]['Tarih'].'</small>
                                                    </div>
                                                </div>
                                                <div class="col-md-1"></div>
                                            </div>
                                        ';
                                    }
                                }
                             ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="post" action="main.php?id=<?php echo $Id ?>&kullanici=<?php echo $KullaniciId ?>">
                                        <div class="form-group panel-border-top">
                                            <label for="message" class="control-label" style="margin-left: 15px">Mesaj</label>
                                            <textarea id="message" rows="5"  name="mesajTekrar" class="form-control border-input" style="width: 95%; margin-left: 15px;" ></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary" style="margin-left: 15px" >Gönder</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                </div>
            </div>
        </div>
        <?php include "footer.php"; ?>
</html>
