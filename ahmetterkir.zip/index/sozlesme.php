<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">
        <?php
        require_once '../sys/BasicDB.php';
        require_once '../sys/function.php';
        Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
        $KullaniciId = $_SESSION['Id'];
        include "header.php";
        ?>
        <div class="main-panel">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar bar1"></span>
                            <span class="icon-bar bar2"></span>
                            <span class="icon-bar bar3"></span>
                        </button>
                        <a class="navbar-brand" href="">Kullanıcı Sözleşmesi</a>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                    	<li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                        </ul>
                    </div>
                </div>
            </nav>

     <div class="content">
        <div class="container-fluid">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 col-lg-offset-1 col-lg-offset-1">
                    <div class="panel panel-info" style="margin-top: 40px;">
                        <div class="panel-heading">
                            <label>Kullanıcı Sözleşmesi</label>
                        </div>
                    </div>
                    <div class="col-xs-12">
                        <div class="content-holder" >
                            <p >
                                <?php echo $seo[0]['Sozlesme']; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     </div>
            <?php include "footer.php" ?>
</html>
