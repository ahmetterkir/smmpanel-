<?php

require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
require_once '../api/api.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];

?>
<html>
<head>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

</html>

<?php 

if (isset($_POST['baslik']) && isset($_POST['mesaj'])) {
    @@$KullaniciId = strip_tags(guvenlik($_GET['id']));
    @@$Baslik = strip_tags($_POST['baslik']);
    @@$Mesaj = strip_tags($_POST['mesaj']);
    $Durum = 'Bekliyor';
    if (empty($Baslik) || empty($Mesaj)){
        echo '<script type = "text/javascript"> swal("Bilgi ", "Lütfen boş alan bırakmayınız.", "info") </script>';
        include "destek.php";
        Yonlendir("destek.php",2);
    }else{
        $destek = $db->insert('destek')
            ->set(array(
                'KullaniciId' => $KullaniciId,
                'Baslik' => $Baslik,
                'Durum' => $Durum
            ));

        if ( $destek ){

            $destekCevap = $db->insert('destekcevap')
                ->set(array(
                    'destekId' => $db->lastId(),
                    'cevaplayanId' => $KullaniciId,
                    'Mesaj' => $Mesaj
                ));
            if ($destekCevap){
                echo '<script type = "text/javascript"> swal("Destek Talebi Oluşturuldu ", "lütfen Bekleyin Yönlendiriliyorsunuz.", "success") </script>';
                include "destek.php";
                Yonlendir("destek.php",2);
            }else{
                echo '<script type = "text/javascript"> swal("Hata ", "Destek talebi oluşturulamadı.", "error") </script>';
                include "destek.php";
                Yonlendir("destek.php",2);
            }
        }
    }
}


if (isset($_POST["mesajTekrar"])) {

    $Id = strip_tags(guvenlik($_GET['id']));
    $KullaniciId = strip_tags(guvenlik($_GET['kullanici']));
    $Mesaj = strip_tags($_POST['mesajTekrar']);

    $destekCevap = $db->insert('destekcevap')
        ->set(array(
            "destekId" => $Id,
            "cevaplayanId" => $KullaniciId,
            "Mesaj" => $Mesaj
        ));

    if ($destekCevap) {
        $query = $db->update('destek')
            ->where('Id', $Id)
            ->set([
                'Durum' => 'Bekliyor'
            ]);
        Yonlendir("destek-aktif.php?id=$Id");
    }else{
        echo '<script type = "text/javascript"> swal("Bilgi", "Destek Talebi Cevaplanamadı.", "info") </script>';
        include "destek-aktif.php";
        Yonlendir("destek-aktif.php",2);
    }
}

    if (isset($_POST["eskiSifre"]) && isset($_POST["yeniSifre"]) && isset($_POST["yeniSifreTekrar"])) {

        $Id = strip_tags(guvenlik($_GET['id']));
        $eskiSifre = strip_tags($_POST["eskiSifre"]);
        $yeniSifre = strip_tags($_POST["yeniSifre"]);
        $yeniSifreTekrar = strip_tags($_POST["yeniSifreTekrar"]);

        $query = $db->from('kullanicilar')
            ->where('Id', $Id)
            ->all();

        if (empty($eskiSifre) || empty($yeniSifre) || empty($yeniSifreTekrar)){
            echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info") </script>';
            include "uyepaneli.php";
            Yonlendir("uyepaneli.php",2);
        }elseif ($yeniSifre != $yeniSifreTekrar) {
            echo '<script type = "text/javascript"> swal("Bilgi", "Şifreler Uyuşmuyor.", "info") </script>';
            include "uyepaneli.php";
            Yonlendir("uyepaneli.php",2);
        }elseif ($query[0]['Sifre'] != $eskiSifre) {
            echo '<script type = "text/javascript"> swal("Bilgi", "Eski Şifreniz Yanlış.", "info") </script>';
            include "uyepaneli.php";
            Yonlendir("uyepaneli.php",2);
        }else{
            $update = $db->update('kullanicilar')
                ->where('Id', $Id)
                ->set([
                    'Sifre' => $yeniSifre
                ]);
            if ($update){
                Yonlendir("cikis.php");
            }else{
                echo '<script type = "text/javascript"> swal("Bilgi", "Şifre Değiştirme Yapılmadı.", "info") </script>';
                include "uyepaneli.php";
                Yonlendir("uyepaneli.php",2);
            }
        }
    }

if (isset($_POST["apiKeyGuncelle"])) {

    $Id = strip_tags(guvenlik($_GET['id']));
    $karakterler = "1234567890abcdefghijklmnopqrstuvwxyz";
    for($i=0; $i < 10; $i++)
    {
        $key .= $karakterler{rand(0,35)};
    }
    $apiKey = strip_tags($key) . uniqid();
    $apiKey = strtoupper(substr(sha1(md5($apiKey)), -25));
    $query = $db->update('kullanicilar')
            ->where('Id', $Id)
            ->set([
                'ApiKey' => $apiKey
            ]);
        Yonlendir("uyepaneli.php");
}

if ( isset($_POST['servis']) &&  isset($_POST['link']) &&  isset($_POST['miktar'])  &&  isset($_POST['fiyat']) ||  isset($_POST['yorum'])){
    $servis = strip_tags($_POST['servis']);
    $link = strip_tags($_POST['link']);
    $fiyat = strip_tags($_POST['fiyat']);
    $miktar = strip_tags($_POST['miktar']);
    $yorum = htmlspecialchars(strip_tags($_POST['yorum']));


    $Kullanici = $db->from('kullanicilar')
        ->where('Id', $KullaniciId)
        ->all();

    $ozelFiyat = $db->from('ozelfiyat')
        ->where('KullaniciId', $KullaniciId)
        ->where('ServisId', $servis)
        ->all();

    $servisBilgileri = $db->from('servisler')
        ->where('Id', $servis)
        ->all();

    if($servisBilgileri[0]['ServisYontemi'] != 'Paket'){
        if(count($ozelFiyat) > 0) {
            $Birim = $ozelFiyat[0]['Fiyat'] / 1000;
            $Fiyat = $miktar * $Birim;
        }else{
            $Birim = $servisBilgileri[0]['Fiyat'] / 1000;
            $Fiyat = $miktar * $Birim;
        }
    }else{
        $Fiyat = $servisBilgileri[0]['Fiyat'];
    }

    $apiBilgileri = $db->from('api')
        ->where('Id', $servisBilgileri[0]['ApiId'])
        ->all();

    if ($Kullanici[0]['Bakiye'] < $Fiyat ) {
        echo '<script type = "text/javascript"> swal("Bakiyeniz Yetersiz.. ", "lütfen Bakiye Ekleyin.", "info") </script>';
        include "index.php";
        Yonlendir("index.php",2);
    }elseif ($servisBilgileri[0]['ServisYontemi'] != 'Paket' && $miktar <= 0) {
        echo '<script type = "text/javascript"> swal("Bilgi", "Miktarı Yanlış Girdiniz.", "info") </script>';
        include "index.php";
        Yonlendir("index.php",2);
    }elseif ($servisBilgileri[0]['ServisYontemi'] != 'Paket' && $miktar < $servisBilgileri[0]['Minimum']) {
        echo '<script type = "text/javascript"> swal("Bilgi", "Minimum Miktardan Az Girdiniz.", "info") </script>';
        include "index.php";
        Yonlendir("index.php",2);
    }elseif ($servisBilgileri[0]['ServisYontemi'] != 'Paket' && $miktar > $servisBilgileri[0]['Maximum']) {
        echo '<script type = "text/javascript"> swal("Bilgi", "Maximum Miktardan Fazla Girdiniz..", "info") </script>';
        include "index.php";
        Yonlendir("index.php",2);
    }elseif (empty($link)) {
        echo '<script type = "text/javascript"> swal("Bilgi", "Url/kullanıcı adı bölümü boş.", "info") </script>';
        include "index.php";
        Yonlendir("index.php",2);
    }elseif ($Fiyat == 0) {
        echo '<script type = "text/javascript"> swal("Bilgi ", "İşlem başarısız oldu", "info") </script>';
        include "index.php";
        Yonlendir("index.php",2);
    }else{
        $api = new Api();
        $api->api_url = $apiBilgileri[0]['ApiUrl'];
        $api->api_key = $apiBilgileri[0]['ApiKey'];

        if ($apiBilgileri[0]['ApiUrl'] == "https://smmturk.net/api/v2.php") {
	        if ($servisBilgileri[0]['ServisYontemi'] == "Servis"){
	            @@$order = $api->order(array("service" => $servisBilgileri[0]['ApiNo'], 'link' => $link, 'quantity' => $miktar, "yayinci" =>250 ));
	          }elseif($servisBilgileri[0]['ServisYontemi'] == "Paket"){
	            @@$order = $api->order(array("service" => $servisBilgileri[0]['ApiNo'], 'link' => $link, "yayinci" =>250));
	          }else{
	            @@$order = $api->order(array("service" => $servisBilgileri[0]['ApiNo'], 'link' => $link, 'comments' => $yorum, "yayinci" =>250));
	        }
        }

        @@$siparisId = $order->order;
        if ($siparisId > 0){
            $query = $db->insert('siparisler')
                ->set(array(
                    "SiparisId" => $order->order,
                    "ApiId" => $servisBilgileri[0]['ApiId'],
                    "ApiNo" => $servisBilgileri[0]['ApiNo'],
                    "ServisAdi" => $servisBilgileri[0]['ServisAdi'],
                    "Kalan" => $miktar,
                    "BaslangicSayisi" => 0,
                    "Yorum" => $yorum,
                    "Fiyat" => $Fiyat,
                    "ServisId" => $servisBilgileri[0]['Id'],
                    "Miktar" => $miktar,
                    "Link" => $link,
                    "Durum" =>  'Pending',
                    "Kullanici" => $Kullanici[0]['KullaniciAdi'],
                ));

                if($query){
                    $Bakiye =$Kullanici[0]['Bakiye'] - $Fiyat;
                    $update = $db->update('kullanicilar')
                        ->where('Id', $KullaniciId)
                        ->set([
                            'Bakiye' => $Bakiye
                        ]);
                    if($update){
                        echo '<script type = "text/javascript"> swal("Siparişiniz Başarıyla alındı ", "lütfen Bekleyin Yönlendiriliyorsunuz.", "success") </script>';
                        include "index.php";
                        Yonlendir("index.php",2);
                    }else{
                        echo '<script type = "text/javascript"> swal("Bilgi", "Siparişiniz Alınmadı!", "info") </script>';
                        include "index.php";
                        Yonlendir("index.php",2);
                    }
                }else{
                    echo '<script type = "text/javascript"> swal("Bilgi", "Siparişiniz Alınmadı!", "info") </script>';
                    include "index.php";
                    Yonlendir("index.php",2);
                }
        }else{
            $update = $db->update('servisler')
                ->where('Id', $servisBilgileri[0]['Id'])
                ->set([
                    'Durum' => 'Pasif'
                ]);
            echo '<script type = "text/javascript"> swal("Bilgi", "Servis Pasife Alındı!", "info") </script>';
            include "index.php";
            Yonlendir("index.php",2);

        }

    }
}
?>