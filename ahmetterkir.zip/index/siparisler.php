<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];
$KullaniciAdi = $_SESSION['Kullanici'];
?>

<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php 
			include "header.php";
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="">Sipariş Geçmişi</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                    	<li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h4 class="title">Sipariş Geçmişi</h4>
                        </div>
                        <div class="content table-responsive table-full-width">
                            <table class="table table-striped">
                                <thead>
                                <th style="text-align: center;">ID</th>
                                <th style="text-align: center;">Servis Adı</th>
                                <th style="text-align: center;">Kullanıcı Adı/ URL</th>
                                <th style="text-align: center;">Başlangıç Sayısı</th>
                                <th style="text-align: center;">Miktar</th>
                                <th style="text-align: center;">Ödeme Tutarı</th>
                                <th style="text-align: center;">Durum</th>
                                <th style="text-align: center;">Kalan</th>
                                <th style="text-align: center;">Tarih</th>
                                </thead>
                                <?php
                                $totalRecord = $db->from('siparisler')
                                    ->where('Kullanici', $KullaniciAdi)
                                    ->select('count(Id) as total')
                                    ->total();
                                $pageLimit = 10;
                                $pageParam = 'sayfa';
                                $pagination = $db->pagination($totalRecord, $pageLimit, $pageParam);
                                $query = $db->from('siparisler')
                                    ->where('Kullanici', $KullaniciAdi)
                                    ->orderby('Id', 'DESC')
                                    ->limit($pagination['start'], $pagination['limit'])
                                    ->all();
                                for ($i = 0; $i < count($query); $i++) {


                                    if ($query[$i]['Durum'] == "Pending" || $query[$i]['Durum'] == "Inprogress" || $query[$i]['Durum'] == "In progress" ){
                                        $query[$i]['Durum'] = 'Beklemede';
                                    }elseif ($query[$i]['Durum'] == "Complete" || $query[$i]['Durum'] == "Completed"){
                                        $query[$i]['Durum'] = "Tamamlandı";
                                    }elseif ($query[$i]['Durum'] == "Partial"){
                                        $query[$i]['Durum'] = "Kısmi Tamamlandı";
                                    }elseif ($query[$i]['Durum'] == "Processing"){
                                        $query[$i]['Durum'] = "İşlemde";
                                    }elseif ($query[$i]['Durum'] == "Cancel" || $query[$i]['Durum'] == "Cancelled" || $query[$i]['Durum'] == "Canceled"){
                                        $query[$i]['Durum'] = "İptal Edildi";
                                    }else{
                                        $query[$i]['Durum'] = "Error";
                                    }
                                    echo '
                                                    <tr style="text-align: center;">
                                                        <td>' .$query[$i]['Id']. '</td>
                                                        <td>' .$query[$i]['ServisAdi'].'</td>
                                                        <td>' .$query[$i]['Link'].'</td>
                                                        <td>' .$query[$i]['BaslangicSayisi'].'</td>
                                                        <td>' .$query[$i]['Miktar']. '</td>
                                                        <td>' .$query[$i]['Fiyat'].'<i class="fa fa-try"></td>
                                                        <td>' .$query[$i]['Durum'].'</td>
                                                        <td>' .$query[$i]['Kalan'].'</td>
                                                        <td>' .$query[$i]['Tarih'].'</td>
                                                   </tr>';
                                }
                                echo $db->showPagination('?'.$pageParam.'=[page]');
                                ?>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <?php include "footer.php" ?>
</html>
