<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];

$query = $db->from('kullanicilar')
    ->where('Id', $KullaniciId)
    ->all();
?>
<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php
			include "header.php";
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="">Üye Paneli</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                    	<li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row col-lg-8 col-md-12 col-md-offset-2" >
                    <div class="col-lg-12 col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Şifre Değiştir</h4>
                            </div>
                            <div class="content">
                                <form method="post" action="main.php?id=<?php echo $KullaniciId ?>">
                                    <div class="row">
                                        <div >
                                            <div class="form-group col-lg-12 col-md-12 " >
                                                <label>Eski Şifreniz</label>
                                                <input type="password" class="form-control border-input" name="eskiSifre" placeholder="Eski Şifreniz" >
                                            </div>
                                        </div>
                                        <div >
                                            <div class="form-group col-lg-12 col-md-12 ">
                                                <label>Yeni Şifreniz</label>
                                                <input type="password" class="form-control border-input" name="yeniSifre" placeholder="Yeni Şifreniz" >
                                            </div>
                                        </div>
                                        <div >
                                            <div class="form-group col-lg-12 col-md-12 ">
                                                <label>Yeni Şifreniz</label>
                                                <input type="password" class="form-control border-input" name="yeniSifreTekrar" placeholder="Yeni Şifre Tekrar" >
                                            </div>
                                        </div>
                                    </div>

                                    <div class="text-left">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Değiştir</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>

                            </div>
                        </div>
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Api Key</h4>
                            </div>
                            <div class="content">
                                <form method="post" action="main.php?id=<?php echo $KullaniciId ?>">
                                    <div class="row">
                                        <div >
                                            <div class="form-group col-lg-12 col-md-12 " >
                                                <label>Api Key</label>
                                                <input  class="form-control border-input" value="<?php echo $query[0]['ApiKey'] ?>" name="apiKeyGuncelle"  readonly/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-left">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Değiştir</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include "footer.php"?>

</html>