<?php 
$id=$_GET["id"];
if (strlen($id) > 0 && isset($id)) {
    getCategoriesDetails($id);
}

function getCategoriesDetails($id){
    try{
        require_once '../sys/BasicDB.php';
        require_once '../sys/function.php';
    }catch (PDOException $h) {

        $hata=$h->getMessage();

        echo "<b>HATA VAR :</b> ".$hata;

    }

	$userid = $_SESSION['Id'];
if(isset($userid)):
    $userprice = $db->from('ozelfiyat')
        ->where('KullaniciId', $userid)
        ->where('ServisId', $id)
        ->all();
endif;
    $result = $db->from('servisler')
        ->where('Id', $id)
        ->orderby('Fiyat', 'ASC')
        ->all();

    $ApiDetay = $db->from('api')
        ->where('Id', $result[0]['ApiId'])
        ->all();
        
	if ($ApiDetay[0]['ApiUrl'] == "https://smmturk.net/api/v2.php") {
	    $Aciklama = $result[0]['Aciklama'];
	    $ServisYontemi = $result[0]['ServisYontemi'];
	    $Fiyat = $result[0]['Fiyat'];
	}



    if (isset($userid) && count($userprice) > 0) {
        $Fiyat = $userprice[0]['Fiyat'];
    }
    $result = array(
    'Aciklama' => $Aciklama,
    'ServisYontemi' => $ServisYontemi,
    'Fiyat' => $Fiyat );
    echo json_encode($result);

}


 ?>