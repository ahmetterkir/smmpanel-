<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];
$KullaniciAdi = $_SESSION['Kullanici'];
?>
<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php 
			include "header.php";
            $query = $db->from('kullanicilar')
            ->where('Id', $KullaniciId)
            ->all();

            $tamamlanan = $db->from('siparisler')
                ->where('Durum', 'Completed')
                ->where('Kullanici', $KullaniciAdi)
            ->all();

            $iptal = $db->from('siparisler')
            ->where('Durum', 'Canceled')
            ->where('Kullanici', $KullaniciAdi)
            ->all();
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="">Anasayfa</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="icon-big icon-info  text-center">
                                            <i class="ti-wallet"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>Kullanılabilir Bakiye</p>
                                                <?php echo $query[0]['Bakiye']." TL" ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="icon-big icon-success text-center">
                                            <i class="fa fa-check-square fa-x"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>Tamamlanan Sipariş</p>
                                                <?php echo count($tamamlanan); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="icon-big icon-danger text-center">
                                            <i class="fa fa-minus-square fa-x"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>İptal Edilen Sipariş</p>
                                                <?php echo count($iptal); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    if ($query[0]['Bakiye'] < 5 ){
                        echo  '
                                <div class="well"  style="background-color: firebrick; color: #fff; margin-bottom: 10px;" >
                                    <p style="text-align: center;">
                                             Merhaba '.$query[0]["KullaniciAdi"].', Bakiyen azalmış görünüyor. Bakiye Yüklemek için <a  style="color:#fff" href="bakiye.php"> TIKLAYIN </a> 

                                    </p>
                                </div>
                        ';
                    }
                    $duyuru = $db->from('duyuru')
                        ->where('DuyuruBolumu', 'yenisiparis')
                        ->all();
                    for ($i=0; $i <count($duyuru) ; $i++) {
                        echo ' 
                                <div class="well"  style="background-color: fff">
                                    <p style="text-align: center;">
                                        '.$duyuru[$i]["DuyuruAciklama"].'
                                    </p>
                                </div>
                            ';
                    }
                ?>

                <div class="row col-lg-10 col-md-10 col-md-offset-1 col-lg-offset-1" >
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Yeni Sipariş</h4>
                            </div>
                            <div class="content">
                                <form action="main.php" method="post">
                                    <div class="row">
                                        <div >
                                            <div class="form-group col-lg-12 col-md-12 " >
                                                <label >Kategori Seçiniz</label >
                                                <select type="text" class="form-control border-input" id="kategori" name="kategori">
                                                    <?php
                                                        $query = $db->from('kategori')
                                                            ->where('Durum', 'Aktif')
                                                            ->orderby('Id', 'ASC')
                                                            ->all();
                                                        for ($i=0; $i<count($query) ; $i++) {
                                                            echo '
                                                              <option value="'.$query[$i]['KategoriAdi'].'" >'.$query[$i]['KategoriAdi'].'</option>
                                                            ';
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div >
                                            <div class="form-group col-lg-12 col-md-12 " >
                                                <label >Servis Seçiniz</label >
                                                <select type="text" class="form-control border-input" id="servis" name="servis">
                                                </select>
                                            </div>
                                        </div>
                                        <div >
                                            <div class="form-group col-lg-12 col-md-12  ">
                                                <label>Açıklama</label>
                                                <textarea class="form-control" rows="7" name="aciklama"  id="aciklama" disabled="" > </textarea>
                                            </div>
                                        </div>
                                        <div >
                                            <div class="form-group col-lg-12 col-md-12  ">
                                                <label id="link" >Link </label>
                                                <input class="form-control border-input" type="text" name="link"  />
                                            </div>
                                        </div>
                                        <div>
                                            <div id="miktarDiv" class="form-group col-lg-12 col-md-12 " >
                                                <label id="miktarLabel">Miktar </label>
                                                <input class="form-control border-input" name="miktar" type="text" id="miktar"  placeholder="Miktarı giriniz.." />
                                            </div>
                                        </div>
                                        <div  id="yorum" style="height: 0px;visibility: hidden; padding-left: 0px; padding-right: 0px;" >
                                            <div id="yorumDiv" class="form-group col-lg-12 col-md-12">
                                                <label id="yorumLabel" style="margin-bottom: 20px;">Yorum </label>
                                                <textarea  id="yorumText" class="form-control border-input"  name="yorum" rows="3" ></textarea>
                                            </div>
                                        </div>
                                        <div >
                                            <div id="tutarDiv" class="form-group col-lg-12 col-md-12  ">
                                                <label >Tutar </label>
                                                <input class="form-control border-input" id="fiyat" name="fiyat" type="text" placeholder="" readonly/>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="text-left">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Satın Al</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        <?php include "footer.php" ?>
<script type="text/javascript">

    var miktar = document.getElementById("miktar");
    var miktarLabel = document.getElementById("miktarLabel");
    var fiyat = document.getElementById("fiyat");
    var aciklama = document.getElementById("aciklama");
    var yorum = document.getElementById("yorum");
    var servis = document.getElementById("servis");
    var yorumLabel = document.getElementById("yorumLabel");
    var yorumText = document.getElementById("yorumText");
    var miktarDiv = document.getElementById("miktarDiv");
    var yorumDiv = document.getElementById("yorumDiv");
    var tutarDiv = document.getElementById("tutarDiv");


    $('#servis').change(function () {
        var option = $(this).find('option:selected');
        $.get('selected.php', {
            id: option.val(),
        }, function (data) {
            var obj = jQuery.parseJSON(data);

            document.getElementById("aciklama").innerHTML = obj.Aciklama;
            if (obj.Fiyat > 0 ) {
                miktar.addEventListener("keyup", myFunction);
                function myFunction() {
                    var miktar= $('#miktar').val();
                    var birim = (obj.Fiyat / 1000 );
                    var toplam = (birim * miktar);
                    $('#fiyat').val(toplam);
                }
            }

            if (obj.ServisYontemi == 'Yorum') {
                yorum.style.visibility = "visible";
                yorumText.style.height = "auto";
                yorumText.style.marginBottom = "500px";
                yorumDiv.style.marginBottom = "120px";
                yorum.style.height = "auto";
                miktar.value = "";
                fiyat.value = "";
            }else{
                yorum.style.visibility = "hidden";
                yorum.style.height = "0px";
                yorumLabel.style.height = "0px";
                yorumLabel.visibility = "hidden";
                yorumText.style.height = "0px";
                yorumDiv.style.height = "0px";
                yorumDiv.visibility = "hidden";
                yorumDiv.style.marginBottom = "0px";
                miktar.value = "";
                fiyat.value = "";
            }

            if (obj.ServisYontemi == 'Paket') {
                miktarLabel.style.visibility = "hidden";
                miktarLabel.style.height = "0px";
                miktar.style.visibility = "hidden";
                miktar.style.height = "0px";
                miktarDiv.style.visibility = "hidden";
                miktarDiv.style.height = "0px";
                tutarDiv.style.marginTop = "-30px";
                fiyat.value = obj.Fiyat;
                miktar.value = "";
            }else{
                miktarLabel.style.visibility = "visible";
                miktarLabel.style.height = "auto";
                miktar.style.visibility = "visible";
                miktar.style.height = "auto";
                miktarDiv.style.visibility = "visible";
                miktarDiv.style.height = "auto";
                miktar.value = "";
                fiyat.value = "";
                tutarDiv.style.marginTop = "0px";

            }

        });
    });
</script>


<script type="text/javascript">
    $('#kategori').change(function () {
        var option = $(this).find('option:selected');
        $.get('kategorisec.php', {
            kategori: option.val()
        }, function (data) {
            var obj = jQuery.parseJSON(data);
            html = "";
            for (var i = 0; i < obj.length; i++) {
                html += "<option value=" + obj[i].Id + ">" + obj[i].ServisAdi + " - " + obj[i].Fiyat + "TL" + "</option>"
            }
            document.getElementById("servis").innerHTML = html;

            var index = $(this).find('option:selected').val();

            if (index == null) {
                index = 0;
            }else{
                index = option.index();
            }

            $.get('selected.php', {
                id: obj[index].Id,
            }, function (data) {
                var obj = jQuery.parseJSON(data);
                document.getElementById("aciklama").innerHTML = obj.Aciklama;

                if (obj.ServisYontemi == 'Yorum') {
                    yorum.style.visibility = "visible";
                    yorumText.style.height = "auto";
                    yorumText.style.marginBottom = "500px";
                    yorumDiv.style.marginBottom = "120px";
                    yorum.style.height = "auto";
                    miktar.value = "";
                    fiyat.value = "";
                }else{
                    yorum.style.visibility = "hidden";
                    yorum.style.height = "0px";
                    yorumLabel.style.height = "0px";
                    yorumLabel.visibility = "hidden";
                    yorumText.style.height = "0px";
                    yorumDiv.style.height = "0px";
                    yorumDiv.visibility = "hidden";
                    yorumDiv.style.marginBottom = "0px";
                    miktar.value = "";
                    fiyat.value = "";
                }

                if (obj.ServisYontemi == 'Paket') {
                    miktarLabel.style.visibility = "hidden";
                    miktarLabel.style.height = "0px";
                    miktar.style.visibility = "hidden";
                    miktar.style.height = "0px";
                    miktarDiv.style.visibility = "hidden";
                    miktarDiv.style.height = "0px";
                    tutarDiv.style.marginTop = "-30px";
                    fiyat.value = obj.Fiyat;
                    miktar.value = "";
                }else{
                    miktarLabel.style.visibility = "visible";
                    miktarLabel.style.height = "auto";
                    miktar.style.visibility = "visible";
                    miktar.style.height = "auto";
                    miktarDiv.style.visibility = "visible";
                    miktarDiv.style.height = "auto";
                    miktar.value = "";
                    fiyat.value = "";
                    tutarDiv.style.marginTop = "0px";

                }

                if (obj.Fiyat > 0 ) {
                    miktar.addEventListener("keyup", myFunction);
                    function myFunction() {
                            var miktar= $('#miktar').val();
                        var birim = (obj.Fiyat / 1000);
                            var toplam = (birim * miktar);
                            $('#fiyat').val(toplam);
                    }
                }
            });
        });
    });

    $.get('kategorisec.php', {
        kategori: document.getElementById("kategori").options[0].value
    }, function (data) {
        var obj = jQuery.parseJSON(data);
        html = "";
        for (var i = 0; i < obj.length; i++) {
            html += "<option value=" + obj[i].Id + ">" + obj[i].ServisAdi + " - " + obj[i].Fiyat + "TL" +"</option>"
        }
        document.getElementById("servis").innerHTML = html;

        $.get('selected.php', {
            id: obj[0].Id,
        }, function (data) {
            var objd = jQuery.parseJSON(data);
            document.getElementById("aciklama").innerHTML = obj[0].Aciklama;
            document.getElementById("fiyat").innerHTML = obj[0].Fiyat;
            if (obj[0].Fiyat > 0 ) {
                miktar.addEventListener("keyup", myFunction);
                function myFunction() {
                        var miktar =$('#miktar').val();
                        var birim = (objd.Fiyat / 1000 );
                        var toplam = (birim * miktar);
                    $('#fiyat').val(toplam);

                }
            }
            if (obj[0].ServisYontemi == 'Yorum') {
                yorum.style.visibility = "visible";
                yorum.style.height = "auto";
            }else{
                yorum.style.visibility = "hidden";
                yorum.style.height = "0px";
                yorumLabel.style.height = "0px";
                yorumLabel.visibility = "hidden";
                yorumText.style.height = "0px";
                yorumDiv.style.height = "0px";
                yorumDiv.visibility = "hidden";
            }

            if (obj[0].ServisYontemi == 'Paket') {
                miktarLabel.style.visibility = "hidden";
                miktarLabel.style.height = "0px";
                miktar.style.visibility = "hidden";
                miktar.style.height = "0px";
                miktarDiv.style.visibility = "hidden";
                miktarDiv.style.height = "0px";
                tutarDiv.style.marginTop = "-30px";
                fiyat.value = obj[0].Fiyat;

            }
        });
    });

</script>

</html>
