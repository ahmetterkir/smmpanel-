<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];
?>
<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php 
			include "header.php";
            require_once '../sys/BasicDB.php';
            require_once '../sys/function.php';
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="">Api Dökümantasyon</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                    	<li>
                            <a href="cikis.php" >
                            	<i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

<div class="content">
   <div class="container-fluid">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
            <div class="col-lg-10 col-md-12 col-sm-12 col-xs-12 col-lg-offset-1 col-lg-offset-1">
                <div class="panel panel-info" style="margin-top: 40px;">
                    <div class="panel-heading">
                        <label>Api Döküman</label>
                    </div>
                </div>
                <div class="well api well-float">
                    <div class="center-big-content-block">
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <td class="width-40">Post Methodu</td>
                                <td>POST</td>
                            </tr>
                            <tr>
                                <td>API URL</td>
                                <td id="apiUrl"> </td>
                            </tr>
                            <tr>
                                <td>Api Formatı</td>
                                <td>JSON</td>
                            </tr>
                            </tbody>
                        </table>
                        <h4 class="m-t-md"><strong>Service Listesi</strong></h4>
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th class="width-40">Parametreler</th>
                                <th>Açıklama</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>key</td>
                                <td>ApiKey</td>
                            </tr>
                            <tr>
                                <td>action</td>
                                <td>Add, Status</td>
                            </tr>
                            </tbody>
                        </table>
                        <p><strong>Örnek Kod</strong></p>
                        <pre>[
            {
                "service": 1,
                "name": "Takipçi",
                "type": "Default",
                "category": "İnstagram Takipçi",
                "rate": "0.90",
                "min": "100",
                "max": "8500"
            }
        ]
        </pre>
                        <h4 class="m-t-md"><strong>Sipariş Ekleme</strong></h4>
                        <div id="type_0" style="">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th class="width-40">Parametreler</th>
                                    <th>Açıklama</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>key</td>
                                    <td>Api Keyiniz</td>
                                </tr>
                                <tr>
                                    <td>action</td>
                                    <td>Yapmak istediğiniz işlem, örn: Add</td>
                                </tr>
                                <tr>
                                    <td>service</td>
                                    <td>Servis id</td>
                                </tr>
                                <tr>
                                    <td>link</td>
                                    <td>Sipariş url</td>
                                </tr>
                                <tr>
                                    <td>quantity</td>
                                    <td>Miktar</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>

                        <p><strong>Örnek Kod</strong></p>
                        <pre>
        {
            "orderID": 10
        }
                    </pre>
                        <h4 class="m-t-md"><strong>Sipariş Durumu</strong></h4>
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th class="width-40">Parametreler</th>
                                <th>Açıklama</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>key</td>
                                <td>Api Keyiniz</td>
                            </tr>
                            <tr>
                                <td>action</td>
                                <td>Yapmak istediğiniz işlem, örn: Status</td>
                            </tr>
                            <tr>
                                <td>order </td>
                                <td>Sipariş id</td>
                            </tr>
                            </tbody>
                        </table>
                        <a href="ornek.txt" class="btn btn-default m-t" target="_blank">Örnek PHP Kodu</a>
                    </div>
                </div>
            </div>
        </div>
   </div>
</div>
        <?php include "footer.php" ?>
        <script>
            $(document).ready(function () {
                $.post('../sys/function.php', {
                        action: "load-home-page"
                    },
                    function (obj) {
                        rs = JSON.parse(obj);
                        $("#apiUrl").text(rs.data.ayarlar[0].ApiUrl);
                    });
            });
        </script>
</html>
