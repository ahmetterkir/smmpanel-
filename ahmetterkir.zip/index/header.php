<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Kullanici($_SESSION['Kullanici'], $_SESSION['Sifre']);
$KullaniciId = $_SESSION['Id'];

$seo = $db->from('ayarlar')
    ->all();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title id="title"></title>
    <!--
        META TAG
    -->
    <meta charset="UTF-8">
    <meta name="description" content="<?php echo $seo[0]['SiteAciklamasi'] ?>">
    <meta name="keywords" content="<?php echo $seo[0]['AnahtarKelimeler'] ?>">
    <meta name="author" content="Mehmet MAŞA">
    <!--
    META TAG BİTİŞ
-->
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
    	<div class="sidebar-wrapper" >
            <div class="logo">
                <a href="index.php" class="simple-text">
                    <?php
                        $query = $db->from('kullanicilar')
                        ->where('Id', $KullaniciId)
                        ->all();
                        echo $query[0]['KullaniciAdi']."<br>";
                        echo "Bakiye : ".$query[0]['Bakiye']." TL";
                    ?>
                </a>
            </div>

            <ul class="nav" >
                <li >
                    <a href="index.php">
                        <i class="ti-shopping-cart"></i>
                        <p>Yeni Sipariş</p>
                    </a>
                </li>
                <li >
                    <a href="servisler.php">
                        <i class="ti-clipboard"></i>
                        <p>Fiyat Listesi</p>
                    </a>
                </li>
                <li>
                    <a href="siparisler.php">
                        <i class="ti-shopping-cart-full"></i>
                        <p>Siparişlerim</p>
                    </a>
                </li>
                <li>
                    <a href="bakiye.php">
                        <i class="ti-wallet"></i>
                        <p>Bakiye Yükle</p>
                    </a>
                </li>
                <li>
                    <a href="destek.php">
                        <i class="ti-headphone-alt"></i>
                        <p>Destek Talebi</p>
                    </a>
                </li>
                <li>
                    <a href="apidokuman.php">
                        <i class="ti-unlink"></i>
                        <p>Api Döküman</p>
                    </a>
                </li>
                <li>
                    <a href="sozlesme.php">
                        <i class="ti-shortcode"></i>
                        <p>Sözleşme</p>
                    </a>
                </li>
                <li>
                    <a href="uyepaneli.php">
                        <i class="ti-user"></i>
                        <p>Üye Panelim</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

</body>

</html>