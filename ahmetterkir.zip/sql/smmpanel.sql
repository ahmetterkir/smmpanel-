-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 15 Kas 2018, 17:40:58
-- Sunucu sürümü: 5.6.42
-- PHP Sürümü: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `smmdemo`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `Id` int(1) NOT NULL,
  `KullaniciAdi` varchar(30) NOT NULL,
  `Sifre` varchar(30) NOT NULL,
  `Durum` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`Id`, `KullaniciAdi`, `Sifre`, `Durum`) VALUES
(1, 'ahmetterkir', 'ahmetterkir', 'Aktif');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `anasayfaayar`
--

CREATE TABLE `anasayfaayar` (
  `birinciBaslik` text NOT NULL,
  `ikinciBaslik` text NOT NULL,
  `nelerYapiyoruz` text NOT NULL,
  `instagram` text NOT NULL,
  `twitter` text NOT NULL,
  `facebook` text NOT NULL,
  `Youtube` text NOT NULL,
  `musteriMemnuniyeti` text NOT NULL,
  `guvenliOdeme` text NOT NULL,
  `destek` text NOT NULL,
  `esnekHarcama` text NOT NULL,
  `akilliFiyatlandirma` text NOT NULL,
  `apiDestegi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `anasayfaayar`
--

INSERT INTO `anasayfaayar` (`birinciBaslik`, `ikinciBaslik`, `nelerYapiyoruz`, `instagram`, `twitter`, `facebook`, `Youtube`, `musteriMemnuniyeti`, `guvenliOdeme`, `destek`, `esnekHarcama`, `akilliFiyatlandirma`, `apiDestegi`) VALUES
('SMMTURK Bayilik Paneli & Servis Sağlayıcısı', 'Fiyatlarımıza Ulaşmak ve Sipariş Vermek İçin Ücretsiz Kayıt Ol', 'İnstagram, Twitter ve Youtube gibi sosyal medyalarda takipçi, beğeni, izlenme satın alarak daha fazla kitleye ulaşabilirsiniz. Biz sizin için en uygun fiyatlardan tamamen otomatik panelimiz ile bunu sağlıyoruz. Kullanımı kolay ve hızlı olan panelimizden üyelik alarak sizde sosyal medyalarda tanınabilirsiniz.\r\n', 'İnstagram Takipçi, Beğeni, İzlenme ve birçok hizmetimizden yararlanabilirsiniz. ', 'Twitter Bot Takipçi, RT, FAV ve birçok servisten yararlanmak için sitemize üye olabilirsiniz.', 'Şuan için facebook servisleri sunmuyoruz. Yakında facebook servislerimiz en uygun fiyatlardan eklenecektir.', 'Youtube İzlenme ve Abone servislerinden yararlanmak için sitemizden üyelik açabilirsiniz.', 'Müşterilerimizi memnun etmek için sürekli çalışıyor ve sitemizi geliştiriyoruz. Sizde mutlu müşterilerin arasına katılmak için üye olun.\r\n', 'Sitemize Kredi kartı veya Havale ile güvenli ödeme yapabilirsiniz. Kredi kartı ödemeleriniz 3D Secure ile korunmaktadır.\r\n', 'Sitemiz üzerinden 7/24 destek talebi ile iletişime geçebilirsiniz. Destek talepleri oldukça hızlı cevaplanmaktadır.\r\n', 'Sitemize yüklediğiniz bakiye ile istediğiniz paketten istediğiniz zaman satın alabilirsiniz. Zaman veya miktar sınırı yok!', 'Verdiğiniz siparişlerde eksik gönderim yapılırsa gönderilmeyen miktarın parası otomatikman iade edilir.', 'Api desteği ile sitemize giriş yapmadan sipariş verebilir, siparişin durumunu kontrol edebilirsiniz.\r\n');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `api`
--

CREATE TABLE `api` (
  `Id` int(4) NOT NULL,
  `ApiAdi` text NOT NULL,
  `ApiUrl` text NOT NULL,
  `ApiKey` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

CREATE TABLE `ayarlar` (
  `SiteBasligi` text NOT NULL,
  `SiteAciklamasi` text NOT NULL,
  `AnahtarKelimeler` text NOT NULL,
  `OdemeYontemi` text NOT NULL,
  `ApiUrl` text NOT NULL,
  `ApiKey` text NOT NULL,
  `ApiSecret` text NOT NULL,
  `mail_Id` varchar(50) NOT NULL,
  `Sozlesme` text NOT NULL,
  `FooterAlani` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`SiteBasligi`, `SiteAciklamasi`, `AnahtarKelimeler`, `OdemeYontemi`, `ApiUrl`, `ApiKey`, `ApiSecret`, `mail_Id`, `Sozlesme`, `FooterAlani`) VALUES
('Sosyal Medya Satış Sitesi', 'İnstagram Takipçi, beğeni izlenme vs', 'takipçi, beğeni, izlenme :)', 'paywant', 'https://smmturk.net/api/v2.php', 'APİ key', 'Api secret', '10', 'SMMTURK.NET Sitesine üye olan herkes sözleşmeyi kabul etmiş sayılırlar. <br>\r\n\r\n1) <b>Ödeme İadeleri :</b> Kullanıcıların yaptıkları ödemeler istenilen hizmet 1 hafta içerisinde sağlanamaz ise iade edilir. Aksi taktirde kullanıcılara iade edilmeyecektir. <br>\r\n1 - a)  <b>Yanlış Sipariş İadeleri :  </b>Yanlış siparişlerin iadeleri yoktur. Yanlış girilen link bulunamadığında kullanıcıya bakiyesi iade edilir eğer girilen link veya kullanıcı adına gönderim sağlandıysa iade yapılmayacaktır. Sipariş girerken tüm sorumluluk kullanıcıya aittir. <br>\r\n2)  <b>Sipariş Tamamlanma Süresi : </b> SMMTURK.NET sitesi manuel işlemlerinin yanında diğer sitelerden api ile servis çekip kullanıcılarına sunmaktadır. SMMTURK.NET sitesinin aracılık yaptığı servislerin gönderim sürelerinde geçikme gibi durumlar olabilir. Kullanıcılar sipariş verirken bunları göz önünde bulundurmalıdır.  <br>\r\n2 - a ) <b>Api ile çekilen servisler :</b> Yabancı takipçi, izlenme, beğeni gibi servislerin hepsi api ile çekilen servislerdir. Bu servislere müdahale hakkımız yoktur. Girilen sipariş iade - iptal edilemez. <br>\r\n3 ) <b>Yapılan ödemeler : </b>Sitemiz paywant alt yapısı ile ödeme almaktadır. Yaptığınız ödemeler otomatik olarak hesabınıza tanımlanır. Paywanttan kaynaklı olarak hesabınıza yansıyan fazla bakiye tespit edildiği takdirde uyarı dahi yapılmadan silinecektir. Eksik yüklenen bakiyeleri destek talebinden bildirirseniz SMMTURK.NET sitesi gerekli incelemelerden sonra bakiyenizi eklemeyi taahhüt eder.  <br>\r\n4 ) SMMTURK.NET sitesi manuel işlemlerini sadece bot (gerçek olmayan) hesaplar üzerinde kullanmaktadır. Gerçek kişilerin hesaplarını ele geçirmez ve gerçek hesaplar üzerinden takip, beğeni işlemi yapmaz. Api ile çekilen servislerde ki takipçi, beğeni işlemlerinde kullanılan hesaplar (gerçek hespa ise) tüm sorumluluk apiyi sağlayan sitededir. SMMTURK.NET sitesi sadece aracılık yapmaktadır.<br>\r\n5) SMMTURK.NET sitesi istediği kullanıcı ile çalışma hakkını gizli tutmaktadır.  SMMTURK.NET sitesi üslubuna dikkat eden, saygılı müşteriler ile çalışmaya özen gösterir ve bu kurala uymayan kullanıcıların bakiyesini iade edip üyeliğini silebilir. <br>\r\n6) Kayıt olan kullanıcılar SMMTURK başlıklı bilgilendirme smsleri almayı kabul etmiş sayılır.<br>\r\n6-b) Kayıtlı kullanıcının isteği üzerine SMMTURK.NET sitesi sms göndermeyeceğini taahhüt eder.<br>\r\n7) Kayıt olan bütün kullanıcılar sözleşmeyi kabul etmiş sayılır. <br>\r\n<b> Kullanıcı Sözleşmesi Düzenleme Tarihi : 21/06/2018 </b>                                                  ', 'Footer Alanı');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `buypayer`
--

CREATE TABLE `buypayer` (
  `Id` int(5) NOT NULL,
  `KullaniciId` int(10) NOT NULL,
  `KullaniciAdi` varchar(50) NOT NULL,
  `OdemeKanali` int(1) NOT NULL,
  `OdemeTutari` float NOT NULL,
  `Durum` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `destek`
--

CREATE TABLE `destek` (
  `Id` int(5) NOT NULL,
  `Tarih` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `KullaniciId` int(50) NOT NULL,
  `Baslik` text NOT NULL,
  `Durum` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `destekcevap`
--

CREATE TABLE `destekcevap` (
  `Id` int(5) NOT NULL,
  `destekId` int(5) NOT NULL,
  `cevaplayanId` varchar(50) NOT NULL,
  `Mesaj` text NOT NULL,
  `Tarih` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `duyuru`
--

CREATE TABLE `duyuru` (
  `Id` int(11) NOT NULL,
  `DuyuruBaslik` text NOT NULL,
  `DuyuruAciklama` text NOT NULL,
  `DuyuruBolumu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategori`
--

CREATE TABLE `kategori` (
  `Id` int(2) NOT NULL,
  `KategoriAdi` text NOT NULL,
  `KategoriNo` int(5) NOT NULL,
  `Durum` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `Id` int(5) NOT NULL,
  `KullaniciAdi` varchar(50) NOT NULL,
  `Sifre` text NOT NULL,
  `Email` text NOT NULL,
  `Bakiye` float NOT NULL,
  `Tarih` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Telefon` varchar(10) NOT NULL,
  `ApiKey` text NOT NULL,
  `Durum` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ozelfiyat`
--

CREATE TABLE `ozelfiyat` (
  `Id` int(5) NOT NULL,
  `KullaniciId` int(5) NOT NULL,
  `ServisId` int(5) NOT NULL,
  `Fiyat` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `payamar`
--

CREATE TABLE `payamar` (
  `Id` int(5) NOT NULL,
  `KullaniciId` int(5) NOT NULL,
  `KullaniciAdi` text NOT NULL,
  `OdemeKanali` int(1) NOT NULL,
  `OdemeTutari` float NOT NULL,
  `Durum` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `paywant`
--

CREATE TABLE `paywant` (
  `ID` int(11) NOT NULL,
  `SiparisID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `ReturnData` varchar(255) NOT NULL,
  `Status` int(11) NOT NULL,
  `OdemeKanali` tinyint(4) NOT NULL,
  `OdemeTutari` double NOT NULL,
  `NetKazanc` double NOT NULL,
  `ExtraData` varchar(255) NOT NULL,
  `Tarih` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `servisler`
--

CREATE TABLE `servisler` (
  `Id` int(3) NOT NULL,
  `ServisAdi` text NOT NULL,
  `KategoriAdi` text NOT NULL,
  `Aciklama` text NOT NULL,
  `Minimum` int(10) NOT NULL,
  `Maximum` int(10) NOT NULL,
  `Fiyat` float NOT NULL,
  `ServisYontemi` text NOT NULL,
  `ApiId` int(3) NOT NULL,
  `ApiNo` int(3) NOT NULL,
  `Durum` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `shopier`
--

CREATE TABLE `shopier` (
  `Id` int(11) NOT NULL,
  `Baslik` text NOT NULL,
  `Aciklama` text NOT NULL,
  `Link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `siparisler`
--

CREATE TABLE `siparisler` (
  `Id` int(10) NOT NULL,
  `Tarih` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SiparisId` int(10) NOT NULL,
  `ApiId` int(3) NOT NULL,
  `ApiNo` int(7) NOT NULL,
  `ServisAdi` text NOT NULL,
  `Kalan` int(7) NOT NULL,
  `BaslangicSayisi` int(7) NOT NULL,
  `Yorum` text,
  `Fiyat` float NOT NULL,
  `ServisId` int(7) NOT NULL,
  `Miktar` int(7) NOT NULL,
  `Link` text NOT NULL,
  `Kullanici` varchar(50) NOT NULL,
  `Durum` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `api`
--
ALTER TABLE `api`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `buypayer`
--
ALTER TABLE `buypayer`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `destek`
--
ALTER TABLE `destek`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `destekcevap`
--
ALTER TABLE `destekcevap`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `duyuru`
--
ALTER TABLE `duyuru`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `KullaniciAdi` (`KullaniciAdi`);

--
-- Tablo için indeksler `ozelfiyat`
--
ALTER TABLE `ozelfiyat`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `payamar`
--
ALTER TABLE `payamar`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `paywant`
--
ALTER TABLE `paywant`
  ADD PRIMARY KEY (`ID`);

--
-- Tablo için indeksler `servisler`
--
ALTER TABLE `servisler`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `shopier`
--
ALTER TABLE `shopier`
  ADD PRIMARY KEY (`Id`);

--
-- Tablo için indeksler `siparisler`
--
ALTER TABLE `siparisler`
  ADD PRIMARY KEY (`Id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `api`
--
ALTER TABLE `api`
  MODIFY `Id` int(4) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `buypayer`
--
ALTER TABLE `buypayer`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `destek`
--
ALTER TABLE `destek`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `destekcevap`
--
ALTER TABLE `destekcevap`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `duyuru`
--
ALTER TABLE `duyuru`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `kategori`
--
ALTER TABLE `kategori`
  MODIFY `Id` int(2) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `ozelfiyat`
--
ALTER TABLE `ozelfiyat`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `payamar`
--
ALTER TABLE `payamar`
  MODIFY `Id` int(5) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `paywant`
--
ALTER TABLE `paywant`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `servisler`
--
ALTER TABLE `servisler`
  MODIFY `Id` int(3) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `shopier`
--
ALTER TABLE `shopier`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `siparisler`
--
ALTER TABLE `siparisler`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
