<?php
	function getIPAdresi()	{
		if(getenv("HTTP_CLIENT_IP")) 
			$ip = getenv("HTTP_CLIENT_IP");
		else if(getenv("HTTP_X_FORWARDED_FOR")){
			$ip = getenv("HTTP_X_FORWARDED_FOR");
			if (strstr($ip, ',')){
				$tmp = explode (',', $ip); $ip = trim($tmp[0]);
			}} 
		else 
			$ip = getenv("REMOTE_ADDR");
		return $ip;
	}
	

	function my_Sql_regcase($str){

    $res = "";

    $chars = str_split($str);
    foreach($chars as $char){
        if(preg_match("/[A-Za-z]/", $char))
            $res .= "[".mb_strtoupper($char, 'UTF-8').mb_strtolower($char, 'UTF-8')."]";
        else
            $res .= $char;
    }

    return $res;
}


	function paywantAntiInjection($sql){
			$sql 			= preg_replace(@my_Sql_regcase("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$sql);
			$sql 			= trim($sql);
			$sql 			= strip_tags($sql);
			$sql 			= addslashes($sql);
			return $sql;
		}//hocam birşey sorucam benim db bağlantımda 
	
	function ChargeSilk($jid,$value)
	{
			connect_db('acc');
		
			$sorgu = mssql_query("SELECT JID FROM SK_Silk WHERE JID='$jid'");
			if(mssql_num_rows($sorgu) == 0)
			{
				$insert = mssql_query("INSERT INTO SK_Silk (JID,silk_own,silk_gift,silk_point) VALUES ('$jid','$value',0,0)");
				if($insert)
					return true;
				else
					return false;
			}else{
				$update  = mssql_query("UPDATE SK_Silk SET silk_own= silk_own + '$value' WHERE JID='$jid'");
				if($update)
					return true;
				else
					return false;
			}
	}
	
	function ChargeTL($username,$jid,$value)
	{
		
		connect_db('acc');
			$kontrol = mssql_num_rows(mssql_query("SELECT * FROM Panel.dbo.TLBakiye WHERE kullaniciadi='$username'"));
			if($kontrol == 0)
			{
				$girdiolustur = mssql_query("INSERT INTO Panel.dbo.TLBakiye (kullaniciadi,jid,tlbakiye) VALUES ('$username','$jid','$value')");
				if($girdiolustur)
				{
						
					return true;
				}
				else
				{
					return false;
				}
			}else
			{
				$eklemeyap = mssql_query("UPDATE Panel.dbo.TLBakiye SET tlbakiye=tlbakiye+'$value' WHERE kullaniciadi='$username'");
				if($eklemeyap)
				{
						return true;
				}
				else
				{
					return false;
				}
			}
	}