<?php
header('Content-Type: application/json');
include "api.php";
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';

@@$apiKey = addslashes(strip_tags($_POST['key']));
@@$ApiYontemi = addslashes(strip_tags($_POST['action']));
@@$servisId = addslashes(strip_tags($_POST['service']));
@@$siparisUrl = addslashes(strip_tags($_POST['link']));
@@$miktar = (intval($_POST['quantity']) > 0) ? addslashes(intval($_POST['quantity'])) : 0;
@@$siparisId = (intval($_POST['order']) > 0) ? addslashes(intval($_POST['order'])) : 0;

$json['error'] = 'yanlis yontem adi';

if ( $ApiYontemi == 'add' ) # Sipariş Ekleme
{
     $kullaniciKontrol = $db->from('kullanicilar')
        ->where('ApiKey', $apiKey)
        ->all();
    if (count($kullaniciKontrol) > 0)
    {
        $servisDetay = $db->from('servisler')
            ->where('Id', $servisId)
            ->all();

        if ( count($servisDetay) > 0 ) {
            $apiDetay = $db->from('api')
                ->where('Id', $servisDetay[0]['ApiId'])
                ->all();

            $ozelFiyat = $db->from('ozelfiyat')
                ->where('KullaniciId', $kullaniciKontrol[0]['Id'])
                ->where('ServisId', $servisDetay[0]['Id'])
                ->all();
            if (count($ozelFiyat) > 0) {
                $fiyat = $ozelFiyat[0]['Fiyat'];
            } else {
                $fiyat = $servisDetay[0]['Fiyat'];
            }

            $tutar = (($miktar * $fiyat) / 1000);

            if (($miktar <= 0) OR ($kullaniciKontrol[0]['Bakiye'] < $tutar)) {
                $json['error'] = 'Bakiyeniz yeterli değil.';
            } elseif ($miktar < $servisDetay[0]['Minimum']) {
                $json['error'] = 'Siparişiniz minimum miktarının altında.';
            } elseif ($miktar > $servisDetay[0]['Maximum']) {
                $json['error'] = 'Siparişiniz maximum miktardan fazla.';
            } else {

                $api = new Api();
                $api->api_url = $apiDetay[0]['ApiUrl'];
                $api->api_key = $apiDetay[0]['ApiKey'];
                
                if ($apiDetay[0]['ApiUrl'] == "https://smmturk.net/api/v2.php") {
	                if ($servisDetay[0]['ServisYontemi'] == "Paket"){
	                    $siparis = $api->order(array("service" => $servisDetay[0]['ApiNo'], 'link' => $siparisUrl, "yayinci" => 250));
	                }elseif ($servisDetay[0]['ServisYontemi'] == "Servis"){                    
	                    $siparis = $api->order(array("service" => $servisDetay[0]['ApiNo'], 'link' => $siparisUrl, 'quantity' => $miktar, "yayinci" => 250));
	                }
                }

                $siparis_id = $siparis->order;
                if (count($siparis_id) > 0) {
                    $query = $db->insert('siparisler')
                        ->set(array(
                            "SiparisId" => $siparis_id,
                            "ApiId" => $servisDetay[0]['ApiId'],
                            "ApiNo" => $servisDetay[0]['ApiNo'],
                            "ServisAdi" => $servisDetay[0]['ServisAdi'],
                            "Kalan" => $miktar,
                            "BaslangicSayisi" => 0,
                            "Yorum" => $yorum,
                            "Fiyat" => $tutar,
                            "ServisId" => $servisDetay[0]['Id'],
                            "Miktar" => $miktar,
                            "Link" => $siparisUrl,
                            "Durum" => 'Pending',
                            "Kullanici" => $kullaniciKontrol[0]['KullaniciAdi'],
                        ));
                }

                $kullaniciBakiyesi = $kullaniciKontrol[0]['Bakiye'] - $tutar;
                if ($query) {
                    $json['order']= $db->lastId();
                    unset($json['error']);
                    $update = $db->update('kullanicilar')
                        ->where('Id', $kullaniciKontrol[0]['Id'])
                        ->set([
                            'Bakiye' => $kullaniciBakiyesi
                        ]);
                }else{
                    $update = $db->update('servisler')
                        ->where('Id', $servisDetay[0]['Id'])
                        ->set([
                            'Durum' => "Pasif"
                        ]);
                }
            }
        }else{
            $json['error'] = 'Servis Bulunamadi!';
        }
    }else{
        $json['error'] = 'Kullanici Bulunamadi!';
    }
}else if ( $ApiYontemi == 'status' ) # Sipariş Durumu
{
    $kullaniciKontrol = $db->from('kullanicilar')
        ->where('ApiKey', $apiKey)
        ->all();
    if (count($kullaniciKontrol) > 0)
    {
        $siparisKontrol = $db->from('siparisler')
            ->where('Id', $siparisId)
            ->where('Kullanici', $kullaniciKontrol[0]['KullaniciAdi'])
            ->all();
        if ( count($siparisKontrol) > 0 )
        {
                $durum = $siparisKontrol[0]['Durum'];
                $kalan = $siparisKontrol[0]['Kalan'];
                $baslangicSayisi = $siparisKontrol[0]['BaslangicSayisi'];
                $fiyat = $siparisKontrol[0]['Fiyat'];

            if ($durum == 'Bekliyor'){
                $durum = 'Pending';
            } else if ($durum == 'İşlemde') {
                $durum = 'Processing';
            }else if ($durum == 'Devam Etmekte'){
                $durum = 'In Processing';
            }else if ($durum == 'Tamamlandı') {
                $durum = 'Completed';
            }else if ($durum == 'Kısmi Tamamlandı') {
                $durum = 'Partial';
            }else if ($durum == 'iptal edildi') {
                $durum = 'Canceled';
            }else if ($durum == 'Error') {
                $durum = 'Hata';
            }

            $json['status'] = $durum;
            $json['start_count'] = $baslangicSayisi;
            $json['charge'] = $fiyat;
            $json['remains'] = $kalan;
            unset($json['error']);
        } else {
            $json['error'] = 'yanlış sipariş numarası';
        }
    } else {
        $json['error'] = 'yanlış API anahtarı';
    }
}else if ( $ApiYontemi == 'balance' ) # Sipariş Durumu
{
    $kullaniciKontrol = $db->from('kullanicilar')
        ->where('ApiKey', $apiKey)
        ->all();

    if (count($kullaniciKontrol) > 0)
    {
        $json['balance'] = $kullaniciKontrol[0]['Bakiye'];
        unset($json['error']);
    }else {
        $json['error'] = 'yanlış API anahtarı';
    }
}else if ( $ApiYontemi == 'services' ) # Servisler
{
    $servisKontrol = $db->from('servisler')
        ->all();

    if (count($servisKontrol) > 0)
    {
        foreach ($servisKontrol as $service) {
            if ($service['ServisYontemi']) {
                if ($service['ServisYontemi'] == "Servis") {
                    $service['ServisYontemi'] = "Default";
                }elseif($service['ServisYontemi'] == "Paket"){
                    $service['ServisYontemi'] = "Package";
                }elseif ($service['ServisYontemi'] == "Yorum" ) {
                    $service['ServisYontemi'] = "Custom Comments ";
                }
            }

            $array[] = array(
                'service' => $service['Id'],
                'name' => $service['ServisAdi'],
                'type' => $service['ServisYontemi'],
                'rate' => $service['Fiyat'],
                'min' => $service['Minimum'],
                'max' => $service['Maximum'],
                'category' => $service['KategoriAdi']
            );
        }
        $json = $array;

        unset($json['error']);
    }else {
        $json['error'] = 'Servis bulunamadı';
    }
}else{
    $json['error'] = 'yanlis yontem tipi';
}


$result = $json;
print_r(json_encode($result));
?>


