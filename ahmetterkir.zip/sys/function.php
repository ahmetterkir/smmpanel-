<?php
/**
 * Created by PhpStorm.
 * User: SONY
 * Date: 23.10.2018
 * Time: 04:24
 */
require_once "BasicDB.php";
function Admin($kadi, $asifre)
{
    if (!isset($kadi) || !isset($asifre)) {
        header('Location: index.php');
    } else {
        require 'config.php';
        $KullaniciAdi = htmlspecialchars(strip_tags($kadi));
        $Sifre = htmlspecialchars(strip_tags($asifre));
    	$sorgu = $db->from('admin')
        ->where('KullaniciAdi', $KullaniciAdi)
        ->where('Sifre', $Sifre)
        ->where('Durum', 'Aktif')
        ->all();
        if (count($sorgu) < 1) {
            header('Location: index.php');
        }
    }
}

function Kullanici($kadi, $asifre)
{
    if (!isset($kadi) || !isset($asifre)) {
        header('Location: index.php');
    } else {
        require 'config.php';
        $KullaniciAdi = htmlspecialchars(strip_tags($kadi));
        $Sifre = htmlspecialchars(strip_tags($asifre));
        $sorgu = $db->from('kullanicilar')
            ->where('KullaniciAdi', $KullaniciAdi)
            ->where('Sifre', $Sifre)
            ->where('Durum', 'Aktif')
            ->all();
        if (count($sorgu) < 1) {
            header('Location: index.php');
        }
    }
}

function Yonlendir($url, $zaman = 0)
{
    if ($zaman != 0) {
        header("Refresh: $zaman; url=$url");
    } else {
        header("Location: $url");
    }
}


if (!function_exists('getResultJson')) {
    function getResultJson($query, $conn)
    {
        $smtp = $conn->prepare($query);
        $smtp->execute();
        $rs = $smtp->fetchAll(\PDO::FETCH_ASSOC);
        return $rs;
    }
};


if (isset($_POST["action"]) && $_POST["action"] != NULL) {
    switch ($_POST["action"]) {
        case 'load-home-page':
            $data["kategoriler"] = getResultJson("SELECT * FROM kategori where  Durum = 'Aktif' ORDER BY Id ASC", $db);
            $data["api"] = getResultJson("SELECT * FROM api", $db);
            $data["kullanicilar"] = getResultJson("SELECT * FROM kullanicilar", $db);
            $data["servisler"] = getResultJson("SELECT * FROM servisler  ORDER BY Id ASC", $db);
            $data["duyuru"] = getResultJson("SELECT * FROM duyuru", $db);
            $data["ayarlar"] = getResultJson("SELECT * FROM ayarlar", $db);
            $data["anasayfaayar"] = getResultJson("SELECT * FROM anasayfaayar", $db);
            echo json_encode(array('success' => true, 'data' => $data));
            break;
        default:

            break;
    }
}


function guvenlik($id)
{
    $GelenId = trim(stripslashes($id));
    $engelle = array("'", '"', "sql", "SQL", "query", "QUERY", "select", "SELECT", "union", "UNION", "order", "ORDER", "by", "BY", "#");
    $id = str_replace($engelle, "", $GelenId);
    return $id;
}

?>