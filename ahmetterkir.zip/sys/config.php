<?php
@session_start();
@ob_start();

try {
	$db = new BasicDB('localhost', 'tuncmedy_ibo', 'tuncmedy_ibo', '2018ibolade');
} catch (PDOException $h) {
    $hata = $h->getMessage();
    echo "<b>HATA VAR :</b> " . $hata;

}
?>