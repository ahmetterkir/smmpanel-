<?php
$config = '../sys/BasicDB.php';
if (file_exists($config)) {
    require_once $config;
}
$function = '../sys/function.php';
if (file_exists($function)) {
    require_once $function;
}
Admin($_SESSION['AdminKullaniciAdi'], $_SESSION['AdminSifre']);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title id="title"></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet"/>

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">
        <?php
        include "header.php";
        ?>

        <div class="main-panel">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar bar1"></span>
                            <span class="icon-bar bar2"></span>
                            <span class="icon-bar bar3"></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="cikis.php"><i class="ti-close"></i>Çıkış Yap</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="content">
                <div class="container-fluid">
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Site Anasayfa Ayarları</h4>
                            </div>
                            <div class="content">
                                <form action="main.php" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Anasayfa Birinci Yazı</label>
                                                <input type="text" class="form-control border-input" name="birinciBaslik"
                                                        id="birinciBaslik" placeholder="Giris Başlığı">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Anasayfa İkinci Yazı</label>
                                                <input type="text" class="form-control border-input"
                                                       name="ikinciBaslik" id="ikinciBaslik"
                                                       placeholder="Üye Ol Başlığı">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Sizin için neler yapıyoruz?</label>
                                        <textarea rows="7" class="form-control border-input" name="nelerYapiyoruz"
                                                   id="nelerYapiyoruz" placeholder="Sizin için neler yapıyoruz?" ></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Instagram</label>
                                                <input type="text" class="form-control border-input" name="instagram"
                                                        id="instagram" placeholder="İnstagram Alanı">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Twitter</label>
                                                <input type="text" class="form-control border-input" name="twitter"
                                                      id="twitter"  placeholder="Twitter Alanı">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Facebook</label>
                                                <input type="text" class="form-control border-input" name="facebook"
                                                     id="facebook"  placeholder="Facebook Alanı">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Youtube</label>
                                                <input type="text" class="form-control border-input" name="Youtube"
                                                      id="Youtube" placeholder="Youtube Alanı">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Müşteri Memnuniyeti</label>
                                        <textarea rows="7" class="form-control border-input" name="musteriMemnuniyeti"
                                                   id="musteriMemnuniyeti" placeholder="Müşteri Memnuniyeti" ></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>3D Güvenli Ödeme</label>
                                        <textarea rows="7" class="form-control border-input" name="guvenliOdeme"
                                                  id="guvenliOdeme"  placeholder="3D Güvenli Ödeme" ></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>7/24 Destek</label>
                                        <textarea rows="7" class="form-control border-input" name="destek"
                                                   id="destek" placeholder="7/24 Destek" ></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Esnek Harcama</label>
                                        <textarea rows="7" class="form-control border-input" name="esnekHarcama"
                                                 id="esnekHarcama" placeholder="Esnek Harcama" ></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Akıllı Fiyatlandırma</label>
                                        <textarea rows="7" class="form-control border-input" name="akilliFiyatlandirma"
                                                  id="akilliFiyatlandirma" placeholder="Akıllı Fiyatlandırma" ></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Api Desteği</label>
                                        <textarea rows="7" class="form-control border-input" name="apiDestegi"
                                                  id="apiDestegi" placeholder="Api Desteği" ></textarea>
                                    </div>
                                    <div class="text-left">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Güncelle</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

</body>

<!--   Core JS Files   -->
<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

<!--  Checkbox, Radio & Switch Plugins -->
<script src="assets/js/bootstrap-checkbox-radio.js"></script>

<!--  Charts Plugin -->
<script src="assets/js/chartist.min.js"></script>

<!--  Notifications Plugin    -->
<script src="assets/js/bootstrap-notify.js"></script>

<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

<!-- Paper Dashboard Core javascript and methods for Demo purpose -->
<script src="assets/js/paper-dashboard.js"></script>

<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

<script>
    $(document).ready(function () {
        $.post('../sys/function.php', {
                action: "load-home-page"
            },
            function (obj) {
                rs = JSON.parse(obj);
                $("#title").text(rs.data.ayarlar[0].SiteBasligi);
                $("#birinciBaslik").val(rs.data.anasayfaayar[0].birinciBaslik);
                $("#ikinciBaslik").val(rs.data.anasayfaayar[0].ikinciBaslik);
                $("#nelerYapiyoruz").val(rs.data.anasayfaayar[0].nelerYapiyoruz);
                $("#instagram").val(rs.data.anasayfaayar[0].instagram);
                $("#twitter").val(rs.data.anasayfaayar[0].twitter);
                $("#facebook").val(rs.data.anasayfaayar[0].facebook);
                $("#Youtube").val(rs.data.anasayfaayar[0].Youtube);
                $("#musteriMemnuniyeti").val(rs.data.anasayfaayar[0].musteriMemnuniyeti);
                $("#guvenliOdeme").val(rs.data.anasayfaayar[0].guvenliOdeme);
                $("#destek").val(rs.data.anasayfaayar[0].destek);
                $("#esnekHarcama").val(rs.data.anasayfaayar[0].esnekHarcama);
                $("#akilliFiyatlandirma").val(rs.data.anasayfaayar[0].akilliFiyatlandirma);
                $("#apiDestegi").val(rs.data.anasayfaayar[0].apiDestegi);
            });
    });
</script>
</html>
