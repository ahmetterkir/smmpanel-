<?php
$config = '../sys/BasicDB.php';
if (file_exists($config)) {
    require_once $config;
}
$function = '../sys/function.php';
if (file_exists($function)) {
    require_once $function;
}
Admin($_SESSION['AdminKullaniciAdi'], $_SESSION['AdminSifre']);
?>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>


    <!-- Bootstrap core CSS     -->
    <link href="admin/assets/css/bootstrap.min.css" rel="stylesheet"/>

    <!-- Animation library for notifications   -->
    <link href="admin/assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="admin/assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="admin/assets/css/demo.css" rel="stylesheet"/>

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="admin/assets/css/themify-icons.css" rel="stylesheet">
</head>
<body>
<script
        src="https://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
        crossorigin="anonymous"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php

// SİTE AYARLARI BAŞLANGIÇ 

if (@@$_POST['SiteBasligi'] || @@$_POST['SiteAciklamasi'] || @@$_POST['AnahtarKelimeler']
    || @@$_POST['OdemeYontemi'] || @@$_POST['ApiUrl'] || @@$_POST['ApiKey']
    || @@$_POST['ApiSecret'] || @@$_POST['Sozlesme'] || @@$_POST['FooterAlani']
    || @@$_POST['mail-Id']) {

    $SiteBasligi = strip_tags($_POST['SiteBasligi']);
    $SiteAciklamasi = strip_tags($_POST['SiteAciklamasi']);
    $AnahtarKelimeler = strip_tags($_POST['AnahtarKelimeler']);
    $OdemeYontemi = strip_tags($_POST['OdemeYontemi']);
    $ApiUrl = strip_tags($_POST['ApiUrl']);
    $ApiKey = strip_tags($_POST['ApiKey']);
    $mail_Id = strip_tags($_POST['mail-Id']);
    $ApiSecret = strip_tags($_POST['ApiSecret']);
    $Sozlesme = $_POST['Sozlesme'];
    $FooterAlani = strip_tags($_POST['FooterAlani']);


    $say = $db->from('ayarlar')
        ->all();

    if (count($say) < 1) {
        $query = $db->insert('ayarlar')
            ->set(array(
                "SiteBasligi" => $SiteBasligi,
                "SiteAciklamasi" => $SiteAciklamasi,
                "AnahtarKelimeler" => $AnahtarKelimeler,
                "OdemeYontemi" => $OdemeYontemi,
                "ApiUrl" => $ApiUrl,
                "ApiKey" => $ApiKey,
                "mail_Id" => $mail_Id,
                "ApiSecret" =>$ApiSecret,
                "Sozlesme" => $Sozlesme,
                "FooterAlani" => $FooterAlani
            ));
        if ($query) {
            include "admin/anasayfa.php";
            Yonlendir("anasayfa.php");
        } else {
            include "admin/anasayfa.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Yapılamadı!.", "error"); </script>';
            Yonlendir("anasayfa", 2);
        }
    } else {
        $update = $db->update('ayarlar')
            ->set([
                'SiteBasligi' => $SiteBasligi,
                'SiteAciklamasi' => $SiteAciklamasi,
                'AnahtarKelimeler' => $AnahtarKelimeler,
                'OdemeYontemi' => $OdemeYontemi,
                'ApiUrl' => $ApiUrl,
                'ApiKey' => $ApiKey,
                'mail_Id' => $mail_Id,
                'ApiSecret' => $ApiSecret,
                'Sozlesme' => $Sozlesme,
                'FooterAlani' => $FooterAlani,
            ]);
        if ($update) {
            include "admin/anasayfa.php";
            Yonlendir("anasayfa.php");
        } else {
            include "admin/anasayfa.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Yapılamadı.", "info"); </script>';
            Yonlendir("anasayfa", 2);
        }

    }

};

// SİTE AYARLARI BİTİŞ - SİTE ANASAYFA AYARLARI BAŞLANGIÇ
if (@@$_POST['birinciBaslik'] || @@$_POST['ikinciBaslik'] || @@$_POST['nelerYapiyoruz']
    || @@$_POST['instagram'] || @@$_POST['twitter'] || @@$_POST['facebook']
    || @@$_POST['Youtube'] || @@$_POST['musteriMemnuniyeti'] || @@$_POST['guvenliOdeme']
    || @@$_POST['destek'] || @@$_POST['esnekHarcama'] || @@$_POST['akilliFiyatlandirma']
    || @@$_POST['apiDestegi']) {

    $birinciBaslik = strip_tags($_POST['birinciBaslik']);
    $ikinciBaslik = strip_tags($_POST['ikinciBaslik']);
    $nelerYapiyoruz = strip_tags($_POST['nelerYapiyoruz']);
    $instagram = strip_tags($_POST['instagram']);
    $twitter = strip_tags($_POST['twitter']);
    $facebook = strip_tags($_POST['facebook']);
    $Youtube = strip_tags($_POST['Youtube']);
    $musteriMemnuniyeti = strip_tags($_POST['musteriMemnuniyeti']);
    $guvenliOdeme = strip_tags($_POST['guvenliOdeme']);
    $destek = strip_tags($_POST['destek']);
    $esnekHarcama = strip_tags($_POST['esnekHarcama']);
    $akilliFiyatlandirma = strip_tags($_POST['akilliFiyatlandirma']);
    $apiDestegi = strip_tags($_POST['apiDestegi']);


    $say = $db->from('anasayfaayar')
        ->all();

    if (count($say) < 1) {
        $query = $db->insert('anasayfaayar')
            ->set(array(
                "birinciBaslik" => $birinciBaslik,
                "ikinciBaslik" => $ikinciBaslik,
                "nelerYapiyoruz" => $nelerYapiyoruz,
                "instagram" => $instagram,
                "twitter" => $twitter,
                "facebook" => $facebook,
                "Youtube" => $Youtube,
                "musteriMemnuniyeti" =>$musteriMemnuniyeti,
                "guvenliOdeme" => $guvenliOdeme,
                "destek" => $destek,
                "esnekHarcama" => $esnekHarcama,
                "akilliFiyatlandirma" => $akilliFiyatlandirma,
                "apiDestegi" => $apiDestegi
            ));
        if ($query) {
            include "admin/siteanasayfa.php";
            Yonlendir("siteanasayfa.php");
        } else {
            include "admin/siteanasayfa.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Yapılamadı!.", "error"); </script>';
            Yonlendir("siteanasayfa", 2);
        }
    } else {
        $update = $db->update('anasayfaayar')
            ->set([
                'birinciBaslik' => $birinciBaslik,
                'ikinciBaslik' => $ikinciBaslik,
                'nelerYapiyoruz' => $nelerYapiyoruz,
                'instagram' => $instagram,
                'facebook' => $facebook,
                'twitter' => $twitter,
                'Youtube' => $Youtube,
                'musteriMemnuniyeti' => $musteriMemnuniyeti,
                'guvenliOdeme' => $guvenliOdeme,
                'destek' => $destek,
                'esnekHarcama' => $esnekHarcama,
                'akilliFiyatlandirma' => $akilliFiyatlandirma,
                'apiDestegi' => $apiDestegi
            ]);
        if ($update) {
            include "admin/siteanasayfa.php";
            Yonlendir("siteanasayfa.php");
        } else {
            include "admin/siteanasayfa.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Yapılamadı.", "info"); </script>';
            Yonlendir("siteanasayfa", 2);
        }
    }
};

//  SİTE ANASAYFA AYARLARI BİTİŞ - KATEGORİ EKLEME


if (isset($_POST['KategoriAdi'], $_POST['KategoriNo'])) {

    $KategoriAdi = strip_tags($_POST['KategoriAdi']);
    $KategoriNo = strip_tags($_POST['KategoriNo']);
    $Durum = "Aktif";

    if (empty($KategoriAdi) || empty($KategoriAdi)) {
        include "kategori.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("kategori.php", 2);
    } else {
        $query = $db->insert('kategori')
            ->set(array(
                "KategoriAdi" => $KategoriAdi,
                "KategoriNo" => $KategoriNo,
                "Durum" => $Durum
            ));
        if ($query) {
            include "kategori.php";
            Yonlendir("kategori.php");
        } else {
            include "kategori.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Yapılamadı!.", "error"); </script>';
            Yonlendir("kategori.php", 2);
        }

    }

}


if (isset($_POST['KategoriAdiDuzenle'], $_POST['KategoriNoDuzenle'])) {

    $KategoriId = strip_tags($_GET['id']);
    $KategoriAdiDuzenle = strip_tags($_POST['KategoriAdiDuzenle']);
    $KategoriNoDuzenle = strip_tags($_POST['KategoriNoDuzenle']);

    if (empty($KategoriAdiDuzenle) || empty($KategoriNoDuzenle)) {
        include "kategoriduzenle.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("kategoriduzenle.php?id=$KategoriId", 2);
    } else {

        /*
            KATEGORİYE AİT SERVİSLERİN KATEGORİ ADINI DEĞİŞTİR!
        */
        $Sonuc = $db->from('kategori')
            ->where('Id', $KategoriId)
            ->all();

        $KategoriAdi = $Sonuc[0]['KategoriAdi']; // KATEGORİ ADI BULUNDU!


        $ServisSonuc = $db->from('servisler')
            ->where('KategoriAdi', $KategoriAdi)
            ->all();

        for ($i = 0; $i < count($ServisSonuc); $i++) {
            $Id = $ServisSonuc[$i]['Id'];
            $query = $db->update('servisler')
                ->where('Id', $Id)
                ->set([
                    'KategoriAdi' => $KategoriAdiDuzenle
                ]);
        }

        /*
            BİTİŞ!
        */
        $kategoriSorgu = $db->update('kategori')
            ->where('Id', $KategoriId)
            ->set([
                'KategoriAdi' => $KategoriAdiDuzenle,
                'KategoriNo' => $KategoriNoDuzenle
            ]);
        if (count($kategoriSorgu)) {
            Yonlendir("kategoriduzenle.php?id=$KategoriId");
        }

    }
}

if (isset($_POST['KategoriDurumunuGuncelle'])) {
    $KategoriID = strip_tags($_GET['id']);
    $KategoriDurumunuGuncelle = strip_tags($_POST['KategoriDurumunuGuncelle']);

    $Kategori = $db->from('kategori')
        ->where('Id', $KategoriID)
        ->all();
    $KategoriAdi = $Kategori[0]['KategoriAdi'];

    $Servisler = $db->from('servisler')
        ->where('KategoriAdi', $KategoriAdi)
        ->all();

    for ($i = 0; $i < count($Servisler); $i++) {
        $Id = $Servisler[$i]['Id'];
        $query = $db->update('servisler')
            ->where('Id', $Id)
            ->set([
                'Durum' => $KategoriDurumunuGuncelle
            ]);
    }
    $sorgu = $db->update('kategori')
        ->where('Id', $KategoriID)
        ->set([
            'Durum' => $KategoriDurumunuGuncelle
        ]);
    Yonlendir("kategori.php");
}

// Servis Ekleme

if (isset($_POST['ServisAdi'], $_POST['ServislerKategoriAdi'], $_POST['Aciklama'], $_POST['Minimum'], $_POST['Maximum'], $_POST['Fiyat'], $_POST['ServisYontemi'], $_POST['ApiId'], $_POST['ApiNo'])) {

    $ServisAdi = strip_tags($_POST['ServisAdi']);
    $ServislerKategoriAdi = strip_tags($_POST['ServislerKategoriAdi']);
    $Fiyat = strip_tags($_POST['Fiyat']);
    $Aciklama = strip_tags($_POST['Aciklama']);
    $Minimum = strip_tags($_POST['Minimum']);
    $Maximum = strip_tags($_POST['Maximum']);
    $ServisYontemi = strip_tags($_POST['ServisYontemi']);
    $ApiId = strip_tags($_POST['ApiId']);
    $ApiNo = strip_tags($_POST['ApiNo']);
    $Durum = "Aktif";

    $servisKontrol = $db->from('servisler')
        ->where('ServisAdi', $ServisAdi)
        ->all();

    if (empty($ServisAdi) || empty($ServislerKategoriAdi) || empty($Fiyat) || empty($Aciklama) || empty($Minimum) || empty($ServisYontemi) || empty($ApiId) || empty($ApiNo) || empty($Durum)) {
        include "servisler.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("servisler.php", 2);

    } elseif(count($servisKontrol) > 0){
        include "servisler.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Servis Adı Kullanılmakta.", "info"); </script>';
        Yonlendir("servisler.php", 2);
    } else {
        $sorgu = $db->insert('servisler')
            ->set(array(
                "ServisAdi" => $ServisAdi,
                "KategoriAdi" => $ServislerKategoriAdi,
                "Aciklama" => $Aciklama,
                "Minimum" => $Minimum,
                "Maximum" => $Maximum,
                "Fiyat" => $Fiyat,
                "ServisYontemi" => $ServisYontemi,
                "ApiId" => $ApiId,
                "ApiNo" => $ApiNo,
                "Durum" => $Durum,
            ));
        if ($sorgu) {
            include "admin/servisler.php";
            Yonlendir("servisler.php");
        } else {
            include "admin/servisler.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Yapılamadı!.", "error"); </script>';
            Yonlendir("servisler", 2);
        }
    }
}

// Servis Ekleme Bitiş - Durum Düzenleme 

if (isset($_POST['ServisDurumDuzenle'])) {
    $ServisId = strip_tags($_GET['id']);
    $ServisDurumDuzenle = strip_tags($_POST['ServisDurumDuzenle']);

    if($ServisDurumDuzenle == "Sil"){
        $query = $db->delete('servisler')
            ->where('Id', $ServisId)
            ->done();

        if ($query) {
            Yonlendir("servisler.php");
        } else {
            include "servisler.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Silme İşlemi Başarısız Oldu.", "info"); </script>';
            Yonlendir("servisduzenle.php?id=$ServisId", 2);
        }
    }else{
        $sorgu = $db->update('servisler')
            ->where('Id', $ServisId)
            ->set(array(
                "Durum" => $ServisDurumDuzenle
            ));

            if ($sorgu) {
                Yonlendir("servisduzenle.php?id=$ServisId");
            } else {
                include "servisler.php";
                echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
                Yonlendir("servisduzenle.php?id=$ServisId", 2);
            }
    }


}

// Durum Düzenleme Bitiş - Servis Düzenleme

if (isset($_POST['ServisAdiDuzenle'], $_POST['ServislerKategoriAdiGuncelle'], $_POST['AciklamaDuzenle'], $_POST['MinimumDuzenle'], $_POST['MaximumDuzenle'], $_POST['FiyatDuzenle'], $_POST['ServisYontemiDuzenle'], $_POST['ApiNoDuzenle'])) {


    $ServisAdiDuzenle = strip_tags($_POST['ServisAdiDuzenle']);
    $ServislerKategoriAdiGuncelle = strip_tags($_POST['ServislerKategoriAdiGuncelle']);
    $AciklamaDuzenle = strip_tags($_POST['AciklamaDuzenle']);
    $MinimumDuzenle = strip_tags($_POST['MinimumDuzenle']);
    $MaximumDuzenle = strip_tags($_POST['MaximumDuzenle']);
    $FiyatDuzenle = strip_tags($_POST['FiyatDuzenle']);
    $ServisYontemiDuzenle = strip_tags($_POST['ServisYontemiDuzenle']);
    $ApiNoDuzenle = strip_tags($_POST['ApiNoDuzenle']);
    $ServisId = @strip_tags($_GET['id']);

    if (empty($ServisAdiDuzenle) || empty($ServislerKategoriAdiGuncelle) || empty($AciklamaDuzenle) || empty($MinimumDuzenle) || empty($MaximumDuzenle) || empty($FiyatDuzenle) || empty($ServisYontemiDuzenle) || empty($ApiNoDuzenle)) {
        include "servisler.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("servisduzenle.php?id=$ServisId", 2);
    } else {
        $sorgu = $db->update('servisler')
            ->where('Id', $ServisId)
            ->set([
                'ServisAdi' => $ServisAdiDuzenle,
                'KategoriAdi' => $ServislerKategoriAdiGuncelle,
                'Aciklama' => $AciklamaDuzenle,
                'Minimum' => $MinimumDuzenle,
                'Maximum' => $MaximumDuzenle,
                'Fiyat' => $FiyatDuzenle,
                'ServisYontemi' => $ServisYontemiDuzenle,
                'ApiNo' => $ApiNoDuzenle,
            ]);
        if ($sorgu) {
            Yonlendir("servisduzenle.php?id=$ServisId");
        } else {
            include "servisler.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
            Yonlendir("servisduzenle.php?id=$ServisId", 2);
        }

    }
}

// KULLANICI DÜZENLEME BÖLÜMÜ 

if (isset($_POST['EmailDuzenle'], $_POST['TelefonDuzenle'])) {


    $EmailDuzenle = strip_tags($_POST['EmailDuzenle']);
    $TelefonDuzenle = strip_tags($_POST['TelefonDuzenle']);
    $KullaniciId = @$_GET['id'];

    if (empty($EmailDuzenle) || empty($TelefonDuzenle)) {
        include "kullaniciduzenle.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("kullaniciduzenle.php?id=$KullaniciId", 2);
    } else {
        $sorgu = $db->update('kullanicilar')
            ->where('Id', $KullaniciId)
            ->set([
                'Email' => $EmailDuzenle,
                'Telefon' => $TelefonDuzenle
            ]);
        if ($sorgu) {
            Yonlendir("kullaniciduzenle.php?id=$KullaniciId");
        } else {
            include "kullaniciduzenle.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
            Yonlendir("kullaniciduzenle.php?id=$KullaniciId", 2);
        }
    }
}

if (isset($_POST['Miktar'], $_POST['BakiyeYontemi'])) {


    $Miktar = strip_tags($_POST['Miktar']);
    $BakiyeYontemi = strip_tags($_POST['BakiyeYontemi']);
    $KullaniciId = @$_GET['id'];

     $Kullanici = $db->from('kullanicilar')
        ->where('Id', $KullaniciId)
        ->all();
     $KullaniciBakiye = $Kullanici[0]['Bakiye'];

    if (empty($Miktar)) {
        include "kullaniciduzenle.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("kullaniciduzenle.php?id=$KullaniciId", 2);
    } else {
        if (is_numeric($Miktar)) {

            if ($BakiyeYontemi == "Ekle") {
                $sorgu = $db->update('kullanicilar')
                    ->where('Id', $KullaniciId)
                    ->set([
                        'Bakiye' => $KullaniciBakiye + $Miktar
                    ]);
            } else {
                $sorgu = $db->update('kullanicilar')
                    ->where('Id', $KullaniciId)
                    ->set([
                        'Bakiye' => $KullaniciBakiye - $Miktar
                    ]);
            }

            if ($sorgu) {
                Yonlendir("kullaniciduzenle.php?id=$KullaniciId");
            } else {
                include "kullaniciduzenle.php";
                echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
                Yonlendir("kullaniciduzenle.php?id=$KullaniciId", 2);
            }
        } else {
            include "kullaniciduzenle.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Sadece Sayı Giriniz!", "info"); </script>';
            Yonlendir("kullaniciduzenle.php?id=$KullaniciId", 2);
        }

    }
}

if (isset($_POST['DurumDuzenle'])) {
    $DurumDuzenle = strip_tags($_POST['DurumDuzenle']);
    $KullaniciId = @$_GET['id'];

    if (empty($DurumDuzenle)) {
        include "kullaniciduzenle.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("kullaniciduzenle.php?id=$KullaniciId", 2);
    } else {

        $sorgu = $db->update('kullanicilar')
        ->where('Id', $KullaniciId)
        ->set([
            'Durum' => $DurumDuzenle
        ]);

        if ($sorgu) {
            Yonlendir("kullaniciduzenle.php?id=$KullaniciId");
        } else {
            include "kullaniciduzenle.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
            Yonlendir("kullaniciduzenle.php?id=$KullaniciId", 2);
        }
    }
}


// KULLANICI DÜZENLEME BİTİŞ

// OZEL FİYAR EKLEME


if (isset($_POST['OzelFiyat'], $_POST['OzelFiyatServisAdi'])) {

    $OzelFiyatServisAdi = strip_tags($_POST['OzelFiyatServisAdi']);
    $OzelFiyat = strip_tags($_POST['OzelFiyat']);
    $KullaniciId = strip_tags($_GET['id']);
    $ServisId = strip_tags($_GET['service']);

    if (empty($OzelFiyatServisAdi) || empty($OzelFiyat) || empty($KullaniciId) || empty($ServisId)) {
        include "ozelfiyat.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("ozelfiyat.php?id=$KullaniciId", 2);
    } else {
        $ozelfiyat = $db->from('ozelfiyat')
            ->where('KullaniciId', $KullaniciId)
            ->where('ServisId', $ServisId)
            ->all();

        if (count($ozelfiyat) > 0) {
            $Sorgu = $db->update('ozelfiyat')
                ->where('KullaniciId', $KullaniciId)
                ->where('ServisId', $ServisId)
                ->set([
                    'Fiyat' => $OzelFiyat
                ]);

            if ($Sorgu) {
                Yonlendir("ozelfiyat.php?id=$KullaniciId");
            } else {
                include "kullaniciduzenle.php";
                echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
                Yonlendir("ozelfiyat.php?id=$KullaniciId", 2);
            }
        } else {
            $insert = $db->insert('ozelfiyat')
                ->set(array(
                    "KullaniciId" => $KullaniciId,
                    "ServisId" => $ServisId,
                    "Fiyat" => $OzelFiyat
                ));

            if ($insert) {
                Yonlendir("ozelfiyat.php?id=$KullaniciId");
            } else {
                include "kullaniciduzenle.php";
                echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Başarısız Oldu.", "info"); </script>';
                Yonlendir("ozelfiyat.php?id=$KullaniciId", 2);
            }
        }
    }
}


// ÖZEL FİYAT BİTİŞ


if (isset($_POST['EskiSifre'], $_POST['YeniSifre'], $_POST['YeniSifreTekrar'])) {

    $AdminId = strip_tags($_GET['id']);
    $EskiSifre = strip_tags($_POST['EskiSifre']);
    $YeniSifre = strip_tags($_POST['YeniSifre']);
    $YeniSifreTekrar = strip_tags($_POST['YeniSifreTekrar']);

    $Sonuc = $db->from('admin')
        ->where('Id', $AdminId)
        ->all();
    $AdminEskiSifre = $Sonuc[0]['Sifre'];

    if (empty($EskiSifre) || empty($YeniSifre) || empty($YeniSifreTekrar)) {
        include "ayar.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("ayar.php", 2);

    } elseif ($YeniSifreTekrar != $YeniSifre) {
        include "ayar.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Şifreler Aynı Değil.", "info"); </script>';
        Yonlendir("ayar.php", 2);
    } elseif ($EskiSifre != $AdminEskiSifre) {
        include "ayar.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Eski Şifreler Aynı Değil.", "info"); </script>';
        Yonlendir("ayar.php", 2);
    } else {
        $update = $db->update('admin')
            ->where('Id', $AdminId)
            ->set([
                'Sifre' => $YeniSifre
            ]);
        if ($update) {
            include "admin/ayar.php";
            Yonlendir("ayar.php");
        } else {
            include "admin/ayar.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Yapılamadı.", "info"); </script>';
            Yonlendir("ayar.php", 2);
        }

    }
}


if (isset($_POST['AdminKadi'], $_POST['AdminSifre'], $_POST['AdminSifreTekrar'])) {


    $AdminKadi = strip_tags($_POST['AdminKadi']);
    $AdminSifre = strip_tags($_POST['AdminSifre']);
    $AdminSifreTekrar = strip_tags($_POST['AdminSifreTekrar']);

    if (empty($AdminKadi) || empty($AdminSifre) || empty($AdminSifreTekrar)) {
        include "ayar.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("ayar.php", 2);

    } elseif ($AdminSifre != $AdminSifreTekrar) {
        include "ayar.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Şifreler Aynı Değil.", "info"); </script>';
        Yonlendir("ayar.php", 2);
    } else {
        $insert = $db->insert('admin')
            ->set(array(
                "KullaniciAdi" => $AdminKadi,
                "Sifre" => $AdminSifre,
                "Durum" => 'Aktif'
            ));

        if ($insert) {
            include "admin/ayar.php";
            Yonlendir("ayar.php");
        } else {
            include "admin/ayar.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Yapılamadı!.", "error"); </script>';
            Yonlendir("ayar", 2);
        }
    }
}

if (isset($_POST['AdminiDuzenle'], $_POST['AdminDurum'])) {

    $AdminId = strip_tags($_GET['id']);
    $AdminiDuzenle = strip_tags($_POST['AdminiDuzenle']);
    $AdminDurum = strip_tags($_POST['AdminDurum']);

    if ($AdminiDuzenle == $AdminId) {
        $update = $db->update('admin')
            ->where('Id', $AdminId)
            ->set([
                'Durum' => $AdminDurum
            ]);

        if ($AdminDurum == "Aktif") {
            Yonlendir("ayar.php");
        } else {
            Yonlendir("cikis.php");
        }
    } else {
        $update = $db->update('admin')
            ->where('Id', $AdminiDuzenle)
            ->set([
                'Durum' => $AdminDurum
            ]);
        Yonlendir("ayar.php");
    }
}

// APİ BÖLÜMÜ

if (isset($_POST['ApiAdiEkle'], $_POST['ApiKeyEkle'])) {

    $ApiAdi = strip_tags($_POST['ApiAdiEkle']);
    $ApiUrl = "https://smmturk.net/api/v2.php";
    $ApiKeyEkle = strip_tags($_POST['ApiKeyEkle']);

    if (empty($ApiAdi) || empty($ApiUrl) || empty($ApiKeyEkle)) {
        include "api.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("api.php", 2);
    } else {
        $insert = $db->insert('api')
            ->set(array(
                "ApiAdi" => $ApiAdi,
                "ApiUrl" => $ApiUrl,
                "ApiKey" => $ApiKeyEkle,
            ));
        if ($insert) {
            include "admin/api.php";
            Yonlendir("api.php");
        } else {
            include "admin/api.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Yapılamadı!.", "error"); </script>';
            Yonlendir("api", 2);
        }
    }


}


if (isset($_POST['ApiAdiDuzenle'], $_POST['ApiKeyDuzenle'])) {

    $ApiId = strip_tags($_GET['id']);
    $ApiAdiDuzenle = strip_tags($_POST['ApiAdiDuzenle']);
    $ApiKeyDuzenle = strip_tags($_POST['ApiKeyDuzenle']);

    if (empty($ApiAdiDuzenle)  || empty($ApiKeyDuzenle) ) {
        include "api.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("api.php", 2);
    } else {
        $update = $db->update('api')
            ->where('Id', $ApiId)
            ->set([
                'ApiAdi' => $ApiAdiDuzenle,
                'ApiKey' => $ApiKeyDuzenle
            ]);
        if ($update) {
            include "admin/api.php";
            Yonlendir("apiduzenle.php?id=$ApiId");
        } else {
            include "admin/api.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Yapılamadı.", "info"); </script>';
            Yonlendir("api.php", 2);
        }
    }


}

if (isset($_POST['ApiyiSil'])) {
    $ApiId = strip_tags($_GET['id']);
    $ApiyiSil = strip_tags($_POST['ApiyiSil']);

    $sorgu = $db->delete('api')
        ->where('Id', $ApiId)
        ->done();

    if ($sorgu) {
        Yonlendir("api.php");
    } else {
        include "api.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
        Yonlendir("apiduzenle.php?id=$ApiId", 2);
    }

}

// Shopier Başlangıç

if (isset($_POST['ShopierBaslik'], $_POST['ShopierAciklama'], $_POST['ShopierLink'])) {


    $ShopierBaslik = strip_tags($_POST['ShopierBaslik']);
    $ShopierAciklama = strip_tags($_POST['ShopierAciklama']);
    $ShopierLink = strip_tags($_POST['ShopierLink']);

    if (empty($ShopierLink) || empty($ShopierAciklama) || empty($ShopierBaslik)) {
        include "shopier.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("shopier.php", 2);
    } else {
        $insert = $db->insert('shopier')
            ->set(array(
                "Baslik" => $ShopierBaslik,
                "Aciklama" => $ShopierAciklama,
                "Link" => $ShopierLink
            ));
        if ($insert) {
            include "shopier.php";
            Yonlendir("shopier.php");
        } else {
            include "shopier.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Yapılamadı!.", "error"); </script>';
        }

    }

}
if (isset($_POST['ShopierDurumunuGuncelle'])) {
    $ShopierId = strip_tags($_GET['id']);

    $sorgu = $db->delete('shopier')
        ->where('Id', $ShopierId)
        ->done();

    if ($sorgu) {
        Yonlendir("shopier.php");
    } else {
        include "shopier.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
        Yonlendir("shopierduzenle.php?id=$ShopierId", 2);
    }

}

if (isset($_POST['ShopierBaslikDuzenle'], $_POST['ShopierAciklamaDuzenle'], $_POST['ShopierLinkDuzenle'])) {
    $ShopierId = strip_tags($_GET['id']);
    $ShopierBaslikDuzenle = strip_tags($_POST['ShopierBaslikDuzenle']);
    $ShopierAciklamaDuzenle = strip_tags($_POST['ShopierAciklamaDuzenle']);
    $ShopierLinkDuzenle = strip_tags($_POST['ShopierLinkDuzenle']);

    if (empty($ShopierBaslikDuzenle) || empty($ShopierAciklamaDuzenle) || empty($ShopierLinkDuzenle)) {
        include "shopier.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("shopierduzenle.php?id=$ShopierId", 2);

    }else{
        $sorgu = $db->update('shopier')
            ->where('Id', $ShopierId)
            ->set([
                'Baslik' => $ShopierBaslikDuzenle,
                'Aciklama' => $ShopierAciklamaDuzenle,
                'Link' => $ShopierLinkDuzenle
            ]);

        if ($sorgu) {
            Yonlendir("shopierduzenle.php?id=$ShopierId");
        } else {
            include "shopier.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
            Yonlendir("shopierduzenle.php?id=$ShopierId", 2);
        }
    }
}
// SHOPİER BİTİŞ!


if (isset($_POST['DuyuruAdi'], $_POST['DuyuruAciklama'], $_POST['DuyuruBolumu'])) {


    $DuyuruAdi = strip_tags($_POST['DuyuruAdi']);
    $DuyuruAciklama = strip_tags($_POST['DuyuruAciklama']);
    $DuyuruBolumu = strip_tags($_POST['DuyuruBolumu']);

    if (empty($DuyuruAdi) || empty($DuyuruAciklama) || empty($DuyuruBolumu)) {
        include "duyuru.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("duyuru.php", 2);
    } else {
        $insert = $db->insert('duyuru')
            ->set(array(
                "DuyuruBaslik" => $DuyuruAdi,
                "DuyuruAciklama" => $DuyuruAciklama,
                "DuyuruBolumu" => $DuyuruBolumu
            ));
        if ($insert) {
            include "duyuru.php";
            Yonlendir("duyuru.php");
        } else {
            include "duyuru.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Ekleme İşlemi Yapılamadı!.", "error"); </script>';
            Yonlendir("duyuru.php", 2);
        }

    }

}

if (isset($_POST['DuyuruSil'])) {
    $DuyuruId = strip_tags($_GET['id']);

    $sorgu = $db->delete('duyuru')
        ->where('Id', $DuyuruId)
        ->done();

    if ($sorgu) {
        Yonlendir("duyuru.php");
    } else {
        include "duyuru.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
        Yonlendir("duyuru.php?id=$DuyuruId", 2);
    }

}


if (isset($_POST['DuyuruAdiDuzenle'], $_POST['DuyuruAciklamaDuzenle'], $_POST['DuyuruBolumuDuzenle'])) {
    $DuyuruId = strip_tags($_GET['id']);
    $DuyuruAdiDuzenle = strip_tags($_POST['DuyuruAdiDuzenle']);
    $DuyuruAciklamaDuzenle = strip_tags($_POST['DuyuruAciklamaDuzenle']);
    $DuyuruBolumuDuzenle = strip_tags($_POST['DuyuruBolumuDuzenle']);
    if (empty($DuyuruAdiDuzenle) || empty($DuyuruAciklamaDuzenle) || empty($DuyuruBolumuDuzenle)) {
        include "duyuru.php";
        echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakamazsınız.", "info"); </script>';
        Yonlendir("duyuruduzenle.php?id=$DuyuruId", 2);

    }else {
        $Update = $db->update('duyuru')
            ->where('Id', $DuyuruId)
            ->set([
                'DuyuruBaslik' => $DuyuruAdiDuzenle,
                'DuyuruAciklama' => $DuyuruAciklamaDuzenle,
                'DuyuruBolumu' => $DuyuruBolumuDuzenle
            ]);

        if ($Update) {
            Yonlendir("duyuruduzenle.php?id=$DuyuruId");
        } else {
            include "duyuru.php";
            echo '<script type = "text/javascript"> swal("Bilgi", "Güncelleme İşlemi Başarısız Oldu.", "info"); </script>';
            Yonlendir("duyuruduzenle.php?id=$ShopierId", 2);
        }
    }
}

if (isset($_POST["adminCevap"])) {

    $Id = strip_tags(guvenlik($_GET['id']));
    $AdminKullaniciAdi = strip_tags(guvenlik($_GET['admin']));
    $Mesaj = strip_tags($_POST['adminCevap']);

    $destekCevap = $db->insert('destekcevap')
        ->set(array(
            "destekId" => $Id,
            "cevaplayanId" => $AdminKullaniciAdi,
            "Mesaj" => $Mesaj
        ));

    if ($destekCevap) {
        $query = $db->update('destek')
            ->where('Id', $Id)
            ->set([
                'Durum' => 'Cevaplandı'
            ]);
        Yonlendir("destek-aktif.php?id=$Id");
    }else{
        echo '<script type = "text/javascript"> swal("Bilgi", "Destek Talebi Cevaplanamadı.", "info") </script>';
        include "destek-aktif.php";
        Yonlendir("destek-aktif.php",2);
    }
}

    if(isset($_POST['destekKapat'])){

        $Id = strip_tags(guvenlik($_GET['id']));
        $query = $db->update('destek')
            ->where('Id', $Id)
            ->set([
                'Durum' => 'Kapatıldı'
            ]);
        if ($query){
            Yonlendir("destek-aktif.php");
        }else{
            echo '<script type = "text/javascript"> swal("Bilgi", "Destek Talebi Kapatılamadı.", "info") </script>';
            include "destek-aktif.php";
            Yonlendir("destek-aktif.php",2);
        }
    }
    

    if(isset($_POST['sifreDegistir'],$_POST['sifreTekrarDegistir'])){

        $Id = strip_tags(guvenlik($_GET['id']));
        $sifreDegistir = strip_tags($_POST['sifreDegistir']);
        $sifreTekrarDegistir = strip_tags($_POST['sifreTekrarDegistir']);

        if ($sifreDegistir != $sifreTekrarDegistir) {
            echo '<script type = "text/javascript"> swal("Bilgi", "Şifreler Uyuşmuyor.", "info") </script>';
            include "kullaniciduzenle.php";
            Yonlendir("kullaniciduzenle.php?id=$Id",2);
        }elseif (empty($sifreDegistir) || empty($sifreTekrarDegistir)) {
            echo '<script type = "text/javascript"> swal("Bilgi", "Boş alan bırakmayınız.", "info") </script>';
            include "kullaniciduzenle.php";
            Yonlendir("kullaniciduzenle.php?id=$Id",2);
        }else{
            $query = $db->update('kullanicilar')
                ->where('Id', $Id)
                ->set([
                    'Sifre' => $sifreDegistir
                ]);

	        if ($query){
	            Yonlendir("kullaniciduzenle.php?id=$Id");
	        }else{
	            echo '<script type = "text/javascript"> swal("Bilgi", "Destek Talebi Kapatılamadı.", "info") </script>';
	            include "kullaniciduzenle.php";
	            Yonlendir("kullaniciduzenle.php?id=$Id",2);
	        }
        }


    }
?>
</body>
</html>
