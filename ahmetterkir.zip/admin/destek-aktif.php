<?php
require_once '../sys/BasicDB.php';
require_once '../sys/function.php';
Admin($_SESSION['AdminKullaniciAdi'], $_SESSION['AdminSifre']);
$AdminId = $_SESSION['AdminId'];
$AdminKullaniciAdi = $_SESSION['AdminKullaniciAdi'];
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Paper Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">
		<?php 
			include "header.php";
            $Id = @trim(stripslashes($_GET["id"]));
            guvenlik($Id);

            if(!is_numeric($Id)){
                Yonlendir('destek.php');
            }

            $destek = $db->from('destek')
            ->where('Id', $Id)
            ->all();

            $query = $db->from('destekcevap')
                ->where('destekId', $Id)
                ->orderby('Id', 'ASC')
            ->all();

            $Kullanici = $db->from('kullanicilar')
                ->where('Id', $destek[0]['KullaniciId'])
                ->all();

            if (count($query) == 0){
                Yonlendir('destek.php');
            }
		?>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="destek.php">Destek Sistemi</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-close"></i>
								<p>Çıkış Yap</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="content">
            <div class="container-fluid">
                <div class="row col-lg-10 col-md-10 col-xs-12 col-md-offset-1 col-xs-offset-0" >
            <div class="row">
                <div class="content-wrapper">
                    <div class="col-lg-10 col-md-10  col-xs-12 col-md-offset-1 col-xs-offset-0 ">
                        <div class="well">
                            <?php
                                if($destek[0]['Durum'] == 'Bekliyor' || $destek[0]['Durum'] == 'Cevaplandı'){
                                    echo '
                                    <form method="post" action="main.php?id='.$Id.'">
                                      <button type="submit" class="btn btn-primary" name="destekKapat" style="float: right" >Talebi Kapat</button>
                                    </form>
                                    ';
                                }
                            ?>
                            <div class="titcket-title"><b>Destek Başlığı : <?php echo $destek[0]['Baslik'] ?> </b></div><br>
                            <?php
                            for ($i=0; $i <count($query) ; $i++) {
                                if($Kullanici[0]['Id'] == $query[$i]['cevaplayanId']){
                                    echo '
                                        <div class="row ticket-message-block ticket-message-right well">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-11">
                                                <div class="ticket-message">
                                                    <div class="message">'.$query[$i]['Mesaj'].'</div>
                                                </div>
                                                <div class="info text-right"><br>
                                                    <strong>Kullanıcı : '.$Kullanici[0]['KullaniciAdi'].' </strong><br>
                                                    <small class="text"><strong>Tarih :</strong> '.$query[$i]['Tarih'].'</small>
                                                </div>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                    ';
                                }else{
                                    echo '
                                            <div class="row ticket-message-block ticket-message-left well" >
                                                <div class="col-md-1"></div>
                                                <div class="col-md-11">
                                                    <div class="ticket-message ">
                                                        <div class="message">'.$query[$i]['Mesaj'].'</div>
                                                    </div>
                                                    <div class="info text-left"><br>
                                                        <strong>Admin İsmi : '.$query[$i]['cevaplayanId'].'</strong><br>
                                                        <small class="text"><strong>Tarih :</strong> '.$query[$i]['Tarih'].'</small>
                                                    </div>
                                                </div>
                                                <div class="col-md-1"></div>
                                            </div>
                                        ';
                                }
                            }
                            ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="post" action="main.php?id=<?php echo $Id?>&admin=<?php echo  $AdminKullaniciAdi ?>">
                                        <div class="form-group panel-border-top">
                                            <label for="message" class="control-label" style="margin-left: 15px">Mesaj</label>
                                            <textarea id="message" rows="5"  name="adminCevap" class="form-control border-input" style="width: 95%; margin-left: 15px;" ></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary" style="margin-left: 15px" >Gönder</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

                </div>
            </div>
        </div>


        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="http://www.creative-tim.com">
                                Creative Tim
                            </a>
                        </li>
                        <li>
                            <a href="http://blog.creative-tim.com">
                               Blog
                            </a>
                        </li>
                        <li>
                            <a href="http://www.creative-tim.com/license">
                                Licenses
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </footer>

    </div>
</div>
</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

</html>
