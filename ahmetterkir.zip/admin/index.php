<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>
    <link rel="stylesheet" href="https://cdn.rawgit.com/Chalarangelo/mini.css/v3.0.0/dist/mini-default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mini.css/3.0.0/mini-default.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>
<body>
<br/>
<div class="container">
    <div class="row">
        <div class="col-sm">
        </div>
        <!-- Adding some flex properties to center the form and some height to the page, these can be omitted -->
        <div class="mobil col-sm-12 col-md-8 col-lg-6"
             style="height: calc(100vh - 10.25rem); display: flex; align-items: center; flex: 0 1 auto; ">
            <form action="giris.php" method="post">
                <fieldset>
                    <legend>Admin Girişi</legend>
                    <div class="input-group fluid">
                        <label for="username" style="width: 90px;">Kullanıcı Adı</label>
                        <input type="text" id="username" name="AdminKullaniciAdi" placeholder="Kullanıcı Adı">
                    </div>
                    <div class="input-group fluid">
                        <label for="pwd" style="width: 90px;">Şifre</label>
                        <input type="password" name="AdminSifre" id="pwd" placeholder="Şifre">
                    </div>
                    <div class="input-group fluid" style="width: 410px;">
                        <button class="primary" type="submit">Giriş Yap</button>
                    </div>
                </fieldset>
            </form>
        </div>
        <div class="col-sm">
        </div>
    </div>
</div>

</body>
</html>