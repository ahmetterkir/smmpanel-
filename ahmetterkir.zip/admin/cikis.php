<?php
session_start();
session_destroy();
session_unset();
unset($_SESSION['oturum']);
unset($_SESSION['AdminKullaniciAdi']);
unset($_SESSION['AdminSifre']);
unset($_SESSION['AdminId']);
header('Location: index.php');
?>