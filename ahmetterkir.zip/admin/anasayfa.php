<?php
$config = '../sys/BasicDB.php';
if (file_exists($config)) {
    require_once $config;
}
$function = '../sys/function.php';
if (file_exists($function)) {
    require_once $function;
}
Admin($_SESSION['AdminKullaniciAdi'], $_SESSION['AdminSifre']);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title id="title"></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet"/>

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">
        <?php
        include "header.php";
        ?>

        <div class="main-panel">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar bar1"></span>
                            <span class="icon-bar bar2"></span>
                            <span class="icon-bar bar3"></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="cikis.php"><i class="ti-close"></i>Çıkış Yap</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="content">
                <div class="container-fluid">
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Site Ayarları</h4>
                            </div>
                            <div class="content">
                                <form action="main.php" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Site Başlığı</label>
                                                <input type="text" class="form-control border-input" name="SiteBasligi"
                                                       id="titleval" placeholder="Site Başlığı">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Site Açıklaması</label>
                                                <input type="text" class="form-control border-input"
                                                       name="SiteAciklamasi" id="description"
                                                       placeholder="Site Açıklaması">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Anahtar Kelimeler</label>
                                                <input type="text" class="form-control border-input"
                                                       name="AnahtarKelimeler" id="keywords"
                                                       placeholder="Anahtar Kelimeler">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-lg-6 col-md-6  ">
                                            <label for="exampleInputEmail1"> Ödeme Yöntemi</label>
                                            <select type="text" id="OdemeYontemi" class="form-control border-input" name="OdemeYontemi">
                                                <option value="paywant">Paywant</option>
                                                <option value="payamar">Payamar</option>
                                                <option value="buypayer">Buypayer</option>
                                                <option value="shopier">Shopier</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Api URL</label>
                                                <input type="text" class="form-control border-input" name="ApiUrl"
                                                       id="ApiUrl" placeholder="Api URL">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-lg-4 col-md-4 col-sm-12">
                                            <label>Api Key - Güvenlik Kodu</label>
                                            <input type="password" class="form-control border-input"  name="ApiKey"
                                                   id="ApiKey"
                                                   placeholder="Api Key">
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label>Api Secret </label>
                                                <input type="password" class="form-control border-input" name="ApiSecret"
                                                       id="ApiSecret" placeholder="Api Secret">
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label>Buypayer Email - Payamar Mağaza Id </label>
                                                <input type="text" class="form-control border-input" name="mail-Id"
                                                       id="mail-Id" placeholder="Buypayer Email - Payamar Mağaza Id">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Footer Alanı</label>
                                                <input type="text" class="form-control border-input" name="FooterAlani"
                                                       id="footeralani" placeholder="Footer Alanı">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Sozleşme Alanı</label>
                                        <textarea rows="7" class="form-control border-input" name="Sozlesme"
                                                  id="Sozlesme" placeholder="Sözleşme Alanı" ></textarea>
                                    </div>
                                    <div class="text-left">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Güncelle</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

</body>

<!--   Core JS Files   -->
<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

<!--  Checkbox, Radio & Switch Plugins -->
<script src="assets/js/bootstrap-checkbox-radio.js"></script>

<!--  Charts Plugin -->
<script src="assets/js/chartist.min.js"></script>

<!--  Notifications Plugin    -->
<script src="assets/js/bootstrap-notify.js"></script>

<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

<!-- Paper Dashboard Core javascript and methods for Demo purpose -->
<script src="assets/js/paper-dashboard.js"></script>

<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

<script>
    $(document).ready(function () {
        $.post('../sys/function.php', {
                action: "load-home-page"
            },
            function (obj) {
                rs = JSON.parse(obj);
                $("#title").text(rs.data.ayarlar[0].SiteBasligi);
                $("#OdemeYontemi").val(rs.data.ayarlar[0].OdemeYontemi);
                $("#titleval").val(rs.data.ayarlar[0].SiteBasligi);
                $("#ApiUrl").val(rs.data.ayarlar[0].ApiUrl);
                $("#ApiKey").val(rs.data.ayarlar[0].ApiKey);
                $('#ApiSecret').val(rs.data.ayarlar[0].ApiSecret);
                $('#mail-Id').val(rs.data.ayarlar[0].mail_Id);
                $('#keywords').val(rs.data.ayarlar[0].AnahtarKelimeler);
                $('#description').val(rs.data.ayarlar[0].SiteAciklamasi);
                $("#footeralani").val(rs.data.ayarlar[0].FooterAlani);
                $("#Sozlesme").val(rs.data.ayarlar[0].Sozlesme);
            });
    });
</script>
</html>
