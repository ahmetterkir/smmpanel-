<?php
$config = '../sys/BasicDB.php';
if (file_exists($config)) {
    require_once $config;
}
$function = '../sys/function.php';
if (file_exists($function)) {
    require_once $function;
}
Admin($_SESSION['AdminKullaniciAdi'], $_SESSION['AdminSifre']);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title id="title"></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet"/>

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <script
            src="https://code.jquery.com/jquery-3.3.1.js"
            integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
            crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">
        <?php
        include "header.php";
        $Id = @trim(stripslashes($_GET["id"]));
        guvenlik($Id);
        $query = $db->from('duyuru')
            ->where('id', $Id)
            ->all();
        $DuyuruBolumu = $query[0]['DuyuruBolumu'];
        if (count($query) < 1) {
            Yonlendir('duyuru.php');
        }
        ?>
        <div class="main-panel">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar bar1"></span>
                            <span class="icon-bar bar2"></span>
                            <span class="icon-bar bar3"></span>
                        </button>
                        <a class="navbar-brand" href="">Duyuru</a>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="cikis.php"><i class="ti-close"></i>Çıkış Yap</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>


            <div class="content">
                <div class="container-fluid">
                    <div class="col-lg-12 ">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Duyuruyu Düzenle</h4>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <form action="main.php?id=<?php echo $Id ?>" method="post">
                                    <div class="modal-body">
                                        <div class="row">
                                            <div>
                                                <div class="form-group col-lg-12 col-md-12  ">
                                                    <label for="exampleInputEmail1" > Duyuru İsmi (İsim Gözükmeyecektir!
                                                        )</label>
                                                    <input type="text" class="form-control border-input"
                                                           name="DuyuruAdiDuzenle" placeholder="Duyuru Adı"
                                                           value="<?php echo $query[0]['DuyuruBaslik']; ?>">
                                                </div>
                                            </div>
                                            <div>
                                                <div class="form-group col-lg-12 col-md-12  ">
                                                    <label for="exampleInputEmail1"> Duyuru Açıklama </label>
                                                    <input type="text" class="form-control border-input"
                                                           name="DuyuruAciklamaDuzenle" placeholder="Duyuru Açıklama"
                                                           value="<?php echo $query[0]['DuyuruAciklama']; ?>">
                                                </div>
                                            </div>
                                            <div>

                                                <div class="form-group col-lg-12 col-md-12  ">
                                                    <label for="exampleInputEmail1"> Duyuru Bölümü </label>
                                                    <select type="text" class="form-control border-input"
                                                            name="DuyuruBolumuDuzenle">
                                                        <option value="yenisiparis" <?= ($DuyuruBolumu == 'yenisiparis') ? 'selected' : ''; ?> >
                                                            Yeni Sipariş
                                                        </option>
                                                        <option value="servisler" <?= ($DuyuruBolumu == 'servisler') ? 'selected' : ''; ?> >
                                                            Fiyat Listesi
                                                        </option>
                                                        <option value="bakiyeonline" <?= ($DuyuruBolumu == 'bakiyeonline') ? 'selected' : ''; ?> >
                                                            Bakiye Online
                                                        </option>
                                                        <option value="bakiyeshopier" <?= ($DuyuruBolumu == 'bakiyeshopier') ? 'selected' : ''; ?> >
                                                            Bakiye Shopier
                                                        </option>
                                                        <option value="destek" <?= ($DuyuruBolumu == 'destek') ? 'selected' : ''; ?> >
                                                            Destek Talepleri
                                                        </option>
                                                        <option value="giris" <?= ($DuyuruBolumu == 'giris') ? 'selected' : ''; ?> >
                                                            Giriş Bölümü
                                                        </option>
                                                        <option value="kayit" <?= ($DuyuruBolumu == 'kayit') ? 'selected' : ''; ?> >
                                                            Kayıt Ol Bölümü
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button style="margin-left: 15px;" type="submit"
                                            class="btn btn-info btn-fill btn-wd">Duyuruyu Düzenle
                                    </button>

                                </form>
                                <hr>
                                <div class="header">
                                    <h4 class="title">Duyuruyu Sil</h4>
                                </div>
                                <div class="content table-responsive table-full-width">
                                    <form action="main.php?id=<?php echo $Id ?>" id="KategoriSil" method="post">
                                        <div class="modal-body">
                                            <div class="row">
                                                <form class="form-horizontal" method="post"
                                                      action="main.php?id=<?php echo $Id ?> ">
                                                    <div class="col-md-12 col-sm-12 col-xs-12  form-group ">
                                                        <div class="form-group col-lg-6 col-sm-6 col-xs-12">
                                                            <label>Duyuru Adı</label>
                                                            <input class="form-control" placeholder="Kategori Adı"
                                                                   disabled="" value="<?php echo $query[0]['DuyuruBaslik']; ?>"/>
                                                        </div>
                                                        <div>
                                                            <div class="form-group col-lg-6 col-sm-6 col-xs-12">
                                                                <label for="exampleInputEmail1"> İşlemi Seçin</label>
                                                                <select type="text" class="form-control border-input"
                                                                        name="DuyuruSil" ">
                                                                <option value="sil"> Sil</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <button style="margin-left: 15px;" type="submit"
                                                                class="btn btn-info btn-fill btn-wd">Duyuruyu sil
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        document.querySelector('#KategoriSil').addEventListener('submit', function (e) {
            var form = this;

            e.preventDefault(); // <--- prevent form from submitting

            swal({
                title: "Düzenlemek İstiyormusunuz?",
                text: "Düzenleme sonucu veri kaybına uğrayabilirsiniz.",
                icon: "warning",
                buttons: [
                    'Hayır',
                    'Evet'
                ],
                dangerMode: true,
            }).then(function (isConfirm) {
                if (isConfirm) {
                    swal({
                        title: 'Düzenlendi!',
                        icon: 'success'
                    }).then(function () {
                        form.submit(); // <--- submit form programmatically
                    });
                } else {
                    swal("İptal Edildi", "", "error");
                }
            })
        });


    </script>
</body>

<!--   Core JS Files   -->
<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

<!--  Checkbox, Radio & Switch Plugins -->
<script src="assets/js/bootstrap-checkbox-radio.js"></script>

<!--  Charts Plugin -->
<script src="assets/js/chartist.min.js"></script>

<!--  Notifications Plugin    -->
<script src="assets/js/bootstrap-notify.js"></script>

<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

<!-- Paper Dashboard Core javascript and methods for Demo purpose -->
<script src="assets/js/paper-dashboard.js"></script>

<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>

<script>
    $(document).ready(function () {
        $.post('../sys/function.php', {
                action: "load-home-page"
            },
            function (obj) {
                rs = JSON.parse(obj);
                $("#title").text(rs.data.ayarlar[0].SiteBasligi);
            });
    });
</script>
</html>
