<?php
$config = '../sys/BasicDB.php';
if (file_exists($config)) {
    require_once $config;
}
$function = '../sys/function.php';
if (file_exists($function)) {
    require_once $function;
}
Admin($_SESSION['AdminKullaniciAdi'], $_SESSION['AdminSifre']);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title id="title"></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet"/>

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">
        <?php
        include "header.php";
        ?>
        <div class="main-panel">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar bar1"></span>
                            <span class="icon-bar bar2"></span>
                            <span class="icon-bar bar3"></span>
                        </button>
                        <a class="navbar-brand" href="">Shopier</a>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-close"></i>
                                    <p>Çıkış Yap</p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Shopier Link Ekle</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="main.php" method="post">
                            <div class="modal-body">
                                <div class="row">
                                    <div>
                                        <div class="form-group col-lg-12 col-md-12  ">
                                            <label for="exampleInputEmail1"> Başlık</label>
                                            <input type="text" class="form-control border-input" name="ShopierBaslik"
                                                   placeholder="Shopier Başlık">
                                        </div>
                                    </div>
                                    <div>
                                        <div class="form-group col-lg-12 col-md-12  ">
                                            <label for="exampleInputEmail1"> Açıklama</label>
                                            <input type="text" class="form-control border-input" name="ShopierAciklama"
                                                   placeholder="Shopier Açıklama">
                                        </div>
                                    </div>
                                    <div>
                                        <div class="form-group col-lg-12 col-md-12  ">
                                            <label for="exampleInputEmail1"> Link Örn ( 565 )</label>
                                            <input type="text" class="form-control border-input" name="ShopierLink"
                                                   placeholder="Shopier Link Örn ( 565 )">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-info btn-fill btn-wd" data-dismiss="modal">Kapat
                                </button>
                                <button type="submit" class="btn btn-info btn-fill btn-wd">Shopier Link Ekle</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <div class="content">
                <div class="container-fluid">
                    <div class="col-md-12">
                        <div class=="button_css2" style="margin-bottom: 15px; ">
                            <button type="submit" class="btn btn-info btn-fill btn-wd" data-toggle="modal"
                                    data-target="#exampleModal">Shopier Link Ekle
                            </button>
                        </div>
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Kategoriler</h4>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>

                                    <th style="text-align: center;">ID</th>
                                    <th style="text-align: center;">Başlık</th>
                                    <th style="text-align: center;">Açıklama</th>
                                    <th style="text-align: center;">Link</th>
                                    <th style="text-align: center;">Düzenle</th>

                                    </thead>
                                    <tbody>
                                    <?php
                                    $totalRecord = $db->from('shopier')
                                        ->select('count(Id) as total')
                                        ->total();
                                    $pageLimit = 10;
                                    $pageParam = 'sayfa';
                                    $pagination = $db->pagination($totalRecord, $pageLimit, $pageParam);
                                    $query = $db->from('shopier')
                                        ->orderby('Id', 'DESC')
                                        ->limit($pagination['start'], $pagination['limit'])
                                        ->all();
                                        for ($i = 0; $i < count($query); $i++) {
                                            echo '
                                                   <tr style="text-align: center;">
                                                        <td>' .$query[$i]['Id']. '</td>
                                                        <td>' .$query[$i]['Baslik'].'</td>
                                                        <td>' .$query[$i]['Aciklama'].'</td>
                                                        <td>' .$query[$i]['Link'].'</td>
                                                        <td><a href="shopierduzenle.php?id=' .$query[$i]['Id']. '" > <button  type="submit" class="btn btn-info btn-fill" >Düzenle</button></td></a>
                                                        
                                                   </tr>';
                                        }
                                        echo $db->showPagination('?'.$pageParam.'=[page]');
                                    ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</body>

<!--   Core JS Files   -->
<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

<!--  Checkbox, Radio & Switch Plugins -->
<script src="assets/js/bootstrap-checkbox-radio.js"></script>

<!--  Charts Plugin -->
<script src="assets/js/chartist.min.js"></script>

<!--  Notifications Plugin    -->
<script src="assets/js/bootstrap-notify.js"></script>

<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

<!-- Paper Dashboard Core javascript and methods for Demo purpose -->
<script src="assets/js/paper-dashboard.js"></script>

<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>
<script>
    $(document).ready(function () {
        $.post('../sys/function.php', {
                action: "load-home-page"
            },
            function (obj) {
                rs = JSON.parse(obj);
                $("#title").text(rs.data.ayarlar[0].SiteBasligi);
            });
    });
</script>
</html>
