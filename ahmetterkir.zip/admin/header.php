<?php
$config = '../sys/BasicDB.php';
if (file_exists($config)) {
    require_once $config;
}
$function = '../sys/function.php';
if (file_exists($function)) {
    require_once $function;
}
Admin($_SESSION['AdminKullaniciAdi'], $_SESSION['AdminSifre']);

?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<div class="sidebar-wrapper">
    <div class="logo">
        <a href="anasayfa.php" class="simple-text">
            Admin Paneli
        </a>
    </div>

    <ul class="nav">
        <li>
            <a href="anasayfa.php">
                <i class="ti-panel"></i>
                <p>Site Ayarları</p>
            </a>
        </li>
        <li>
            <a href="siteanasayfa.php">
                <i class="ti-panel"></i>
                <p>Anasayfa Ayarları</p>
            </a>
        </li>
        <li>
            <a href="kullanicilar.php">
                <i class="ti-user"></i>
                <p>Kullanıcılar</p>
            </a>
        </li>
        <li>
            <a href="kategori.php">
                <i class="ti-view-list"></i>
                <p>Kategoriler</p>
            </a>
        </li>
        <li>
            <a href="servisler.php">
                <i class="ti-shopping-cart"></i>
                <p>Servisler</p>
            </a>
        </li>
        <li>
            <a href="siparisler.php">
                <i class="ti-shopping-cart-full"></i>
                <p>Siparişler</p>
            </a>
        </li>
        <li>
            <a href="destek.php">
                <i class="ti-headphone-alt"></i>
                <p>Destek </p>
            </a>
        </li>
        <li>
            <a href="shopier.php">
                <i class="ti-wand"></i>
                <p>Shopier Entegre</p>
            </a>
        </li>
        <li>
            <a href="duyuru.php">
                <i class="ti-announcement"></i>
                <p>Duyuru Alanları</p>
            </a>
        </li>
        <li>
            <a href="api.php">
                <i class="ti-link"></i>
                <p>Api Bölümü </p>
            </a>
        </li>
        <li>
            <a href="ayar.php">
                <i class="ti-settings"></i>
                <p>Admin Ayar</p>
            </a>
        </li>
    </ul>
</div>
</div>
</body>
</html>